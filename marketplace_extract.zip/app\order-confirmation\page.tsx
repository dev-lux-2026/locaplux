"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";

export default function OrderConfirmation() {
  const params = useSearchParams();
  const sessionId = params.get("session_id");

  const [order, setOrder] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!sessionId) return;

    async function verifyPayment() {
      const res = await fetch(`/api/orders/verify?session_id=${sessionId}`);
      const data = await res.json();

      if (data.order) {
        setOrder(data.order);
      }

      setLoading(false);
    }

    verifyPayment();
  }, [sessionId]);

  if (loading) {
    return (
      <div style={{ padding: "30px", textAlign: "center" }}>
        Vérification du paiement...
      </div>
    );
  }

  if (!order) {
    return (
      <div style={{ padding: "30px", textAlign: "center" }}>
        <h1>Commande introuvable</h1>
        <p>Si vous avez payé, contactez le support.</p>
      </div>
    );
  }

  return (
    <div style={{ padding: "30px", textAlign: "center" }}>
      <h1>Merci pour votre commande !</h1>

      <p>Votre numéro de commande est :</p>
      <h2>{order._id}</h2>

      <p style={{ marginTop: "20px" }}>
        <strong>Total :</strong> {order.total} €
      </p>

      <p>
        <strong>Statut du paiement :</strong>{" "}
        {order.isPaid ? "Payé ✔️" : "En attente"}
      </p>

      <p>
        <strong>Date :</strong>{" "}
        {new Date(order.createdAt).toLocaleString()}
      </p>

      <p style={{ marginTop: "30px" }}>
        Un email de confirmation vous a été envoyé.
      </p>
    </div>
  );
}
