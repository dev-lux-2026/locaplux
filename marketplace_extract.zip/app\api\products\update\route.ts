import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function POST(req: Request) {
  const form = await req.formData();

  const id = form.get("id") as string;
  const name = form.get("name") as string;
  const description = form.get("description") as string;
  const price = Number(form.get("price"));
  const stock = Number(form.get("stock"));

  await prisma.product.update({
    where: { id },
    data: {
      name,
      description,
      price,
      stock,
    },
  });

  return NextResponse.redirect("/seller/products");
}
