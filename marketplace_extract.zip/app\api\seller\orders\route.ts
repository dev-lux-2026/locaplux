import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "../../auth/[...nextauth]/route";

export async function GET() {
  try {
    await connectDB();

    // Récupérer la session NextAuth
    const session = await getServerSession(authOptions);

    if (!session || !session.user) {
      return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
    }

    const userId = session.user.id;
    const role = session.user.role;

    // Vérifier que l'utilisateur est bien un vendeur
    if (role !== "vendor") {
      return NextResponse.json(
        { error: "Accès réservé aux vendeurs" },
        { status: 403 }
      );
    }

    // Récupérer toutes les commandes contenant AU MOINS un produit du vendeur
    const orders = await Order.find({
      "items.vendorId": userId,
    })
      .sort({ createdAt: -1 })
      .lean();

    return NextResponse.json({ orders });
  } catch (error) {
    console.error("Erreur API seller/orders :", error);
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}
