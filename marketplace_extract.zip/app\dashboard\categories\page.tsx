import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function CategoriesPage() {
  const session = await getServerSession();
  if (!session) redirect("/login");

  const categories = await prisma.category.findMany({
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Catégories</h1>
        <Link
          href="/dashboard/categories/new"
          className="px-4 py-2 bg-black text-white rounded"
        >
          Nouvelle catégorie
        </Link>
      </div>

      <div className="bg-white shadow rounded divide-y">
        {categories.map((cat) => (
          <div key={cat.id} className="p-4 flex items-center justify-between">
            <div>
              <p className="font-semibold">{cat.name}</p>
              <p className="text-gray-500 text-sm">{cat.slug}</p>
            </div>

            <Link
              href={`/dashboard/categories/${cat.id}`}
              className="text-blue-600 hover:underline"
            >
              Modifier
            </Link>
          </div>
        ))}

        {categories.length === 0 && (
          <p className="p-4 text-gray-500">Aucune catégorie pour le moment.</p>
        )}
      </div>
    </div>
  );
}
