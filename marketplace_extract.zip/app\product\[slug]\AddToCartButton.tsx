"use client";

import { addToCart } from "@/lib/cart";

export default function AddToCartButton({ product }: any) {
  return (
    <button
      onClick={() => addToCart(product)}
      style={{
        padding: "12px 20px",
        background: "black",
        color: "white",
        border: "none",
        borderRadius: "6px",
        cursor: "pointer",
        marginTop: "20px",
      }}
    >
      Ajouter au panier
    </button>
  );
}
