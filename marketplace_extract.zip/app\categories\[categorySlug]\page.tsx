import Link from "next/link";

export default async function CategoryPage({ params }: any) {
  const { categorySlug } = params;

  // Charger la catégorie via son slug
  const category = await fetch(
    `http://localhost:3000/api/categories?slug=${categorySlug}`,
    { cache: "no-store" }
  ).then((r) => r.json());

  if (!category || category.error) {
    return (
      <div style={{ padding: "30px" }}>
        <h1>Catégorie introuvable</h1>
        <p>La catégorie "{categorySlug}" n'existe pas.</p>
      </div>
    );
  }

  // Charger les produits via l’API
  const products = await fetch(
    `http://localhost:3000/api/categories/${category._id}/products`,
    { cache: "no-store" }
  ).then((r) => r.json());

  if (!products || products.length === 0) {
    return (
      <div style={{ padding: "30px" }}>
        <h1>Catégorie : {category.name}</h1>
        <p>Aucun produit trouvé dans cette catégorie.</p>
      </div>
    );
  }

  return (
    <div style={{ padding: "30px", maxWidth: "1000px", margin: "0 auto" }}>
      <h1 style={{ marginBottom: "20px" }}>Catégorie : {category.name}</h1>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
          gap: "20px",
        }}
      >
        {products.map((p: any) => (
          <Link
            key={p._id}
            href={`/product/${p.slug}`}
            style={{
              border: "1px solid #ddd",
              padding: "15px",
              borderRadius: "8px",
              textDecoration: "none",
              color: "black",
            }}
          >
            <img
              src={p.images?.[0]}
              alt={p.name}
              style={{
                width: "100%",
                height: "180px",
                objectFit: "cover",
                borderRadius: "6px",
              }}
            />

            <h3 style={{ marginTop: "10px" }}>{p.name}</h3>

            <p style={{ fontWeight: "bold", margin: 0 }}>{p.price} €</p>

            {p.originalPrice && (
              <p
                style={{
                  textDecoration: "line-through",
                  color: "#888",
                  fontSize: "14px",
                  margin: 0,
                }}
              >
                {p.originalPrice} €
              </p>
            )}

            {p.boostLevel !== "none" && (
              <span
                style={{
                  background:
                    p.boostLevel === "premium" ? "purple" : "#0070f3",
                  color: "white",
                  padding: "4px 8px",
                  borderRadius: "4px",
                  fontSize: "12px",
                  marginTop: "8px",
                  display: "inline-block",
                }}
              >
                BOOST {p.boostLevel.toUpperCase()}
              </span>
            )}
          </Link>
        ))}
      </div>
    </div>
  );
}
