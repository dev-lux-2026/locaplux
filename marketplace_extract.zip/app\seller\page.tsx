import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";

export default async function SellerHome() {
  const session = await getServerSession();
  if (!session) redirect("/login");
  if (session.user.role !== "seller") redirect("/dashboard");

  return (
    <div className="p-10 space-y-6">
      <h1 className="text-3xl font-bold">Espace Vendeur</h1>

      <div className="grid grid-cols-3 gap-6">
        <a
          href="/seller/products"
          className="p-6 bg-white border rounded shadow hover:shadow-md transition"
        >
          <h2 className="text-xl font-semibold">Mes Produits</h2>
          <p className="text-gray-600">Gérer vos produits</p>
        </a>

        <a
          href="/seller/boosts"
          className="p-6 bg-white border rounded shadow hover:shadow-md transition"
        >
          <h2 className="text-xl font-semibold">Boosts</h2>
          <p className="text-gray-600">Mettre vos produits en avant</p>
        </a>

        <a
          href="/seller/settings"
          className="p-6 bg-white border rounded shadow hover:shadow-md transition"
        >
          <h2 className="text-xl font-semibold">Paramètres</h2>
          <p className="text-gray-600">Informations du vendeur</p>
        </a>
      </div>
    </div>
  );
}
