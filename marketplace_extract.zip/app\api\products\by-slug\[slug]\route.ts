import { NextResponse } from "next/server";

export async function GET(req: Request, { params }: any) {
  await connectDB();

  const product = await Product.findOne({ slug: params.slug }).lean();

  if (!product) {
    return NextResponse.json({ error: "Produit introuvable" }, { status: 404 });
  }

  return NextResponse.json(product);
}
