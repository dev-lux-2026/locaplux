import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const categories = await prisma.category.findMany({
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(categories);
}

export async function POST(req: Request) {
  const { name, slug } = await req.json();

  if (!name || !slug) {
    return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  }

  const category = await prisma.category.create({
    data: { name, slug },
  });

  return NextResponse.json(category);
}
