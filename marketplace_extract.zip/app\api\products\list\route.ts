import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  await connectDB();

  const { searchParams } = new URL(req.url);
  const category = searchParams.get("category");

  const filter: any = {};

  if (category) filter.categorySlug = category;

  // Nettoyage automatique des boosts expirés
  await Product.updateMany(
    { boostExpiresAt: { $lt: new Date() } },
    { boostLevel: "none", boostExpiresAt: null }
  );

  // Tri boosté
  const products = await Product.find(filter).sort({
    boostLevel: -1,
    boostExpiresAt: -1,
    createdAt: -1,
  });

  return NextResponse.json(products);
}
