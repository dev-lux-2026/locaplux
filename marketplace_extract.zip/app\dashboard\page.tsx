import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";

export default async function DashboardPage() {
  const session = await getServerSession();
  if (!session) redirect("/login");

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Dashboard</h1>

      <p className="mb-4">
        Bonjour <strong>{session.user?.name}</strong><br />
        Rôle actuel : <strong>{session.user?.role}</strong>
      </p>

      {session.user?.role === "user" && (
        <form action="/api/seller/request" method="POST">
          <button
            type="submit"
            className="px-4 py-2 bg-green-600 text-white rounded"
          >
            Devenir vendeur
          </button>
        </form>
      )}

      {session.user?.role === "seller" && (
        <p className="text-green-700 font-semibold">
          Vous êtes vendeur validé.
        </p>
      )}

      {session.user?.role === "admin" && (
        <p className="text-blue-700 font-semibold">
          Vous êtes administrateur.
        </p>
      )}
    </div>
  );
}
