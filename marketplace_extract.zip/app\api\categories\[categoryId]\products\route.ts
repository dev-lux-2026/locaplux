import { NextResponse } from "next/server";
import mongoose from "mongoose";

export async function GET(
  req: Request,
  { params }: { params: { categoryId: string } }
) {
  try {
    await connectDB();

    if (!mongoose.Types.ObjectId.isValid(params.categoryId)) {
      return NextResponse.json({ error: "ID invalide" }, { status: 400 });
    }

    const products = await Product.find({
      categoryId: params.categoryId,
    }).sort({ createdAt: -1 });

    return NextResponse.json(products);
  } catch (error) {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
