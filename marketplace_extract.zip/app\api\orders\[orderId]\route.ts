import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";

export async function PATCH(
  req: Request,
  { params }: { params: { orderId: string } }
) {
  try {
    await connectDB();

    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });

    if (!token || token.role !== "seller") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { status } = await req.json();

    const order = await Order.findById(params.orderId);

    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    order.status = status;
    await order.save();

    return NextResponse.json(order);
  } catch (error) {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
