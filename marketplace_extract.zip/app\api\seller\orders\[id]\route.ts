import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "../../auth/[...nextauth]/route";

export async function GET(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    await connectDB();

    const session = await getServerSession(authOptions);
    if (!session || !session.user || session.user.role !== "vendor") {
      return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
    }

    const vendorId = session.user.id;
    const orderId = params.id;

    const order = await Order.findOne({
      _id: orderId,
      "items.vendorId": vendorId,
    }).lean();

    if (!order) {
      return NextResponse.json({ error: "Commande introuvable" }, { status: 404 });
    }

    return NextResponse.json({ order });
  } catch (error) {
    console.error("Erreur GET seller/order detail :", error);
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}

export async function PATCH(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    await connectDB();

    const session = await getServerSession(authOptions);
    if (!session || !session.user || session.user.role !== "vendor") {
      return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
    }

    const vendorId = session.user.id;
    const orderId = params.id;
    const { status } = await req.json();

    const order = await Order.findOne({
      _id: orderId,
      "items.vendorId": vendorId,
    });

    if (!order) {
      return NextResponse.json({ error: "Commande introuvable" }, { status: 404 });
    }

    order.status = status;
    await order.save();

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Erreur PATCH seller/order detail :", error);
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}
