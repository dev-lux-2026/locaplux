import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function POST(req: Request) {
  const form = await req.formData();

  const name = form.get("name") as string;
  const description = form.get("description") as string;
  const price = Number(form.get("price"));
  const stock = Number(form.get("stock"));

  const userId = form.get("userId") || null;

  const product = await prisma.product.create({
    data: {
      name,
      description,
      price,
      stock,
      userId: userId as string,
    },
  });

  return NextResponse.redirect("/seller/products");
}
