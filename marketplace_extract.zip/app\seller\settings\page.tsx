import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";

export default async function SellerSettings() {
  const session = await getServerSession();
  if (!session) redirect("/login");
  if (session.user.role !== "seller") redirect("/dashboard");

  return (
    <div className="p-10 space-y-6">
      <h1 className="text-2xl font-bold">Paramètres du vendeur</h1>

      <div className="p-6 bg-white border rounded shadow">
        <p className="font-semibold">Nom : {session.user.name}</p>
        <p className="text-gray-600">Email : {session.user.email}</p>
      </div>
    </div>
  );
}
