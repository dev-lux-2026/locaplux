"use client";

import { useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";

export default function SearchGlobalPage() {
  const searchParams = useSearchParams();
  const router = useRouter();

  const q = searchParams.get("q") || "";
  const [results, setResults] = useState([]);

  useEffect(() => {
    async function load() {
      if (!q) return;
      const res = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      setResults(data);
    }
    load();
  }, [q]);

  return (
    <div style={{ padding: "30px", maxWidth: "900px", margin: "0 auto" }}>
      <h1>Résultats pour : "{q}"</h1>

      {results.length === 0 && <p>Aucun résultat trouvé.</p>}

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
          gap: "20px",
          marginTop: "20px",
        }}
      >
        {results.map((p: any) => (
          <div
            key={p._id}
            style={{
              border: "1px solid #ddd",
              padding: "15px",
              borderRadius: "8px",
              cursor: "pointer",
            }}
            onClick={() => router.push(`/product/${p.slug}`)}
          >
            <img
              src={p.images?.[0]}
              alt={p.name}
              style={{
                width: "100%",
                height: "150px",
                objectFit: "cover",
                borderRadius: "6px",
              }}
            />

            <h3 style={{ marginTop: "10px" }}>{p.name}</h3>

            <p style={{ fontWeight: "bold" }}>{p.price} €</p>

            {p.boostLevel !== "none" && (
              <span
                style={{
                  background:
                    p.boostLevel === "premium" ? "purple" : "#0070f3",
                  color: "white",
                  padding: "4px 8px",
                  borderRadius: "4px",
                  fontSize: "12px",
                }}
              >
                BOOST {p.boostLevel.toUpperCase()}
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
