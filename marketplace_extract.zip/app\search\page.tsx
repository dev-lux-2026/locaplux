"use client";

import { useState } from "react";

export default function SearchPage() {
  const [address, setAddress] = useState("");
  const [radius, setRadius] = useState(30);
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const [lat, setLat] = useState<number | null>(null);
  const [lng, setLng] = useState<number | null>(null);

  const useMyLocation = () => {
    navigator.geolocation.getCurrentPosition((pos) => {
      setLat(pos.coords.latitude);
      setLng(pos.coords.longitude);
    });
  };

  const geocodeAddress = async () => {
    const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
      address
    )}`;

    const res = await fetch(url);
    const data = await res.json();

    if (data.length > 0) {
      setLat(parseFloat(data[0].lat));
      setLng(parseFloat(data[0].lon));
    }
  };

  const searchProducts = async () => {
    if (!lat || !lng) {
      alert("Veuillez entrer une adresse ou utiliser votre position.");
      return;
    }

    setLoading(true);

    const res = await fetch(
      `/api/products/search?lat=${lat}&lng=${lng}&radius=${radius}`
    );

    const data = await res.json();
    setResults(data);
    setLoading(false);
  };

  return (
    <div style={{ padding: "30px" }}>
      <h1 style={{ fontSize: "28px", marginBottom: "20px" }}>
        Recherche de produits
      </h1>

      <div style={{ marginBottom: "20px" }}>
        <label>Adresse :</label>
        <input
          type="text"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          style={{
            padding: "10px",
            width: "300px",
            border: "1px solid #ccc",
            marginLeft: "10px",
          }}
        />
        <button
          onClick={geocodeAddress}
          style={{
            marginLeft: "10px",
            padding: "10px 20px",
            background: "#0070f3",
            color: "white",
            border: "none",
            cursor: "pointer",
          }}
        >
          Valider l’adresse
        </button>
      </div>

      <button
        onClick={useMyLocation}
        style={{
          padding: "10px 20px",
          background: "green",
          color: "white",
          border: "none",
          cursor: "pointer",
          marginBottom: "20px",
        }}
      >
        Utiliser ma position actuelle
      </button>

      <div style={{ marginBottom: "20px" }}>
        <label>Rayon : {radius} km</label>
        <input
          type="range"
          min="5"
          max="100"
          value={radius}
          onChange={(e) => setRadius(parseInt(e.target.value))}
          style={{ width: "300px", marginLeft: "20px" }}
        />
      </div>

      <button
        onClick={searchProducts}
        style={{
          padding: "10px 20px",
          background: "black",
          color: "white",
          border: "none",
          cursor: "pointer",
        }}
      >
        Rechercher
      </button>

      <div style={{ marginTop: "40px" }}>
        {loading && <p>Recherche en cours...</p>}

        {results.length > 0 && (
          <div>
            <h2>Résultats ({results.length})</h2>

            <div style={{ display: "flex", flexWrap: "wrap", gap: "20px" }}>
              {results.map((p) => (
                <a
                  key={p._id}
                  href={`/product/${p.slug}`}
                  style={{
                    border: "1px solid #ddd",
                    padding: "10px",
                    borderRadius: "8px",
                    width: "220px",
                    textDecoration: "none",
                    color: "black",
                  }}
                >
                  <img
                    src={p.images?.[0]}
                    alt={p.name}
                    style={{
                      width: "100%",
                      height: "150px",
                      objectFit: "cover",
                      borderRadius: "6px",
                    }}
                  />
                  <h4 style={{ marginTop: "10px" }}>{p.name}</h4>
                  <p>{p.price} €</p>
                  <p style={{ color: "#666" }}>{p.distance} km</p>
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
