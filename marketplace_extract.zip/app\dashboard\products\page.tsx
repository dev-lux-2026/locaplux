import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import Link from "next/link";

export default async function ProductsPage() {
  const session = await getServerSession();
  if (!session) redirect("/login");

  const products = await prisma.product.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      category: true,
    },
  });

  return (
    <div className="space-y-8 text-gray-900">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Produits</h1>
        <Link
          href="/dashboard/products/new"
          className="px-4 py-2 bg-black text-white rounded"
        >
          Nouveau produit
        </Link>
      </div>

      <div className="bg-white shadow-sm rounded border border-gray-200 divide-y">
        {products.map((p) => (
          <div key={p.id} className="p-4 flex items-center justify-between">
            <div>
              <p className="font-semibold">{p.name}</p>

              <p className="text-sm text-gray-500">
                {p.price} € — Stock: {p.stock}
              </p>

              <p className="text-sm text-gray-400">
                {p.category ? p.category.name : "Aucune catégorie"}
              </p>
            </div>

            <Link
              href={`/dashboard/products/${p.id}`}
              className="text-blue-600 hover:underline"
            >
              Modifier
            </Link>
          </div>
        ))}

        {products.length === 0 && (
          <p className="p-4 text-gray-500">Aucun produit pour le moment.</p>
        )}
      </div>
    </div>
  );
}
