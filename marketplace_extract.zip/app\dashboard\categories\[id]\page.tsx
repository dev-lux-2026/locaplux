import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import EditCategoryForm from "./form";

export default async function EditCategoryPage({ params }: any) {
  const session = await getServerSession();
  if (!session) redirect("/login");

  const category = await prisma.category.findUnique({
    where: { id: params.id },
  });

  if (!category) redirect("/dashboard/categories");

  return (
    <div className="space-y-6 max-w-lg">
      <h1 className="text-2xl font-bold">Modifier la catégorie</h1>
      <EditCategoryForm category={category} />
    </div>
  );
}
