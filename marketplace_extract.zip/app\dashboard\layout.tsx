import Link from "next/link";

export default function DashboardLayout({ children }) {
  return (
    <div className="flex min-h-screen bg-gray-100 text-gray-900">
      <aside className="w-64 bg-gray-50 border-r border-gray-200 p-6 space-y-6 shadow-sm">
        <h2 className="text-xl font-bold text-gray-900">Dashboard</h2>

        <nav className="space-y-2">
          <Link href="/dashboard" className="block p-2 rounded hover:bg-gray-200">
            Accueil
          </Link>
          <Link href="/dashboard/products" className="block p-2 rounded hover:bg-gray-200">
            Produits
          </Link>
          <Link href="/dashboard/categories" className="block p-2 rounded hover:bg-gray-200">
            Catégories
          </Link>
          <Link href="/dashboard/orders" className="block p-2 rounded hover:bg-gray-200">
            Commandes
          </Link>
          <Link href="/dashboard/settings" className="block p-2 rounded hover:bg-gray-200">
            Paramètres
          </Link>
        </nav>
      </aside>

      <main className="flex-1 p-10">{children}</main>
    </div>
  );
}
