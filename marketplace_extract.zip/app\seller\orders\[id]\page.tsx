"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

export default function SellerOrderDetailPage() {
  const { data: session, status } = useSession();
  const params = useParams();
  const router = useRouter();

  const [order, setOrder] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);

  const id = params?.id as string;

  useEffect(() => {
    if (status === "loading") return;

    if (!session || session.user.role !== "vendor") {
      router.push("/login");
      return;
    }

    async function loadOrder() {
      const res = await fetch(`/api/seller/orders/${id}`);
      const data = await res.json();

      if (data.order) {
        setOrder(data.order);
      }

      setLoading(false);
    }

    loadOrder();
  }, [status, session, id, router]);

  async function changeStatus(newStatus: string) {
    if (!order) return;
    setUpdating(true);

    const res = await fetch(`/api/seller/orders/${order._id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: newStatus }),
    });

    const data = await res.json();
    if (data.success) {
      setOrder({ ...order, status: newStatus });
    }

    setUpdating(false);
  }

  if (loading) {
    return (
      <div style={{ padding: "30px", textAlign: "center" }}>
        Chargement de la commande...
      </div>
    );
  }

  if (!order) {
    return (
      <div style={{ padding: "30px", textAlign: "center" }}>
        Commande introuvable.
      </div>
    );
  }

  const vendorId = session?.user?.id;
  const itemsForVendor = order.items.filter(
    (item: any) => item.vendorId === vendorId
  );

  return (
    <div style={{ padding: "30px", maxWidth: "900px", margin: "0 auto" }}>
      <button
        onClick={() => router.push("/seller/orders")}
        style={{
          marginBottom: "20px",
          padding: "8px 12px",
          borderRadius: "6px",
          border: "1px solid #ddd",
          cursor: "pointer",
          background: "white",
        }}
      >
        ← Retour aux commandes
      </button>

      <h1>Commande #{order._id}</h1>

      <p style={{ color: "#555" }}>
        Reçue le : {new Date(order.createdAt).toLocaleString()}
      </p>

      <h2 style={{ marginTop: "30px" }}>Client</h2>
      <p>
        <strong>Nom :</strong> {order.customer?.name}
      </p>
      <p>
        <strong>Email :</strong> {order.customer?.email}
      </p>
      <p>
        <strong>Adresse :</strong> {order.customer?.address}
      </p>

      <h2 style={{ marginTop: "30px" }}>Articles de cette commande</h2>

      {itemsForVendor.map((item: any) => (
        <div
          key={item._id}
          style={{
            display: "flex",
            gap: "20px",
            borderBottom: "1px solid #ddd",
            paddingBottom: "15px",
            marginBottom: "15px",
          }}
        >
          <img
            src={item.images?.[0]}
            alt={item.name}
            style={{
              width: "100px",
              height: "100px",
              objectFit: "cover",
              borderRadius: "6px",
            }}
          />
          <div>
            <h3>{item.name}</h3>
            <p>{item.price} €</p>
            <p>Quantité : {item.quantity}</p>
          </div>
        </div>
      ))}

      <h2 style={{ marginTop: "30px" }}>Statut de la commande</h2>

      <p>
        Statut actuel :{" "}
        <strong style={{ textTransform: "uppercase" }}>{order.status}</strong>
      </p>

      <div style={{ display: "flex", gap: "10px", marginTop: "10px" }}>
        <button
          disabled={updating}
          onClick={() => changeStatus("pending")}
          style={{
            padding: "8px 12px",
            borderRadius: "6px",
            border: "none",
            cursor: "pointer",
            background: "#ff9800",
            color: "white",
          }}
        >
          En attente
        </button>
        <button
          disabled={updating}
          onClick={() => changeStatus("shipped")}
          style={{
            padding: "8px 12px",
            borderRadius: "6px",
            border: "none",
            cursor: "pointer",
            background: "#2196f3",
            color: "white",
          }}
        >
          Expédiée
        </button>
        <button
          disabled={updating}
          onClick={() => changeStatus("delivered")}
          style={{
            padding: "8px 12px",
            borderRadius: "6px",
            border: "none",
            cursor: "pointer",
            background: "#4caf50",
            color: "white",
          }}
        >
          Livrée
        </button>
      </div>
    </div>
  );
}
