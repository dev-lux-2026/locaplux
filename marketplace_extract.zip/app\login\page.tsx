"use client";

import { signIn } from "next-auth/react";

export default function LoginPage() {
  async function handleLogin(e: any) {
    e.preventDefault();

    const form = new FormData(e.target);
    const email = form.get("email");
    const password = form.get("password");

    await signIn("credentials", {
      email,
      password,
      callbackUrl: "/dashboard",
    });
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-white text-black">
      <h1 className="text-3xl font-bold mb-6">Connexion</h1>

      <button
        onClick={() => signIn("google", { callbackUrl: "/dashboard" })}
        className="px-4 py-2 bg-red-600 text-white rounded mb-6"
      >
        Se connecter avec Google
      </button>

      <form onSubmit={handleLogin} className="p-6 border rounded w-80 bg-white">
        <input name="email" placeholder="Email" className="border p-2 w-full mb-3" />
        <input name="password" type="password" placeholder="Mot de passe" className="border p-2 w-full mb-3" />

        <button className="bg-blue-600 text-white w-full py-2 rounded">Connexion</button>
      </form>
    </div>
  );
}
