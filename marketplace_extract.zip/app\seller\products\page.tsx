import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export default async function SellerProducts() {
  const session = await getServerSession();
  if (!session) redirect("/login");
  if (session.user.role !== "seller") redirect("/dashboard");

  const products = await prisma.product.findMany({
    where: { userId: session.user.id },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="p-10 space-y-6">
      <h1 className="text-2xl font-bold">Mes Produits</h1>

      <a
        href="/seller/products/new"
        className="px-4 py-2 bg-blue-600 text-white rounded"
      >
        Ajouter un produit
      </a>

      <div className="space-y-4">
        {products.length === 0 && <p>Aucun produit pour le moment.</p>}

        {products.map((p) => (
          <div
            key={p.id}
            className="p-4 border rounded bg-white flex justify-between"
          >
            <div>
              <p className="font-semibold">{p.name}</p>
              <p className="text-gray-600">{p.price} €</p>
            </div>

            <div className="flex gap-3">
              <a
                href={`/seller/products/edit/${p.id}`}
                className="px-3 py-1 bg-gray-800 text-white rounded"
              >
                Modifier
              </a>

              <form action="/api/products/delete" method="POST">
                <input type="hidden" name="id" value={p.id} />
                <button
                  type="submit"
                  className="px-3 py-1 bg-red-600 text-white rounded"
                >
                  Supprimer
                </button>
              </form>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
