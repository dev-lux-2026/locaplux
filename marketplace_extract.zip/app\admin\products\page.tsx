"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function AdminProductsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();

  const [products, setProducts] = useState([]);

  // Vérification du rôle admin
  useEffect(() => {
    if (status === "loading") return;
    if (!session?.user || session.user.role !== "admin") {
      router.push("/login");
    }
  }, [session, status, router]);

  const loadProducts = async () => {
    const res = await fetch("/api/products/list");
    const data = await res.json();
    setProducts(data);
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const handleDelete = async (id: string) => {
    if (!confirm("Supprimer ce produit ?")) return;

    const res = await fetch(`/api/products/${id}`, {
      method: "DELETE",
    });

    if (res.ok) {
      loadProducts();
    } else {
      const error = await res.json();
      alert(error.error || "Erreur");
    }
  };

  return (
    <div style={{ padding: "30px" }}>
      <h1 style={{ fontSize: "28px", marginBottom: "20px" }}>
        Gestion des produits
      </h1>

      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          marginTop: "10px",
        }}
      >
        <thead>
          <tr style={{ background: "#f5f5f5" }}>
            <th style={{ padding: "10px", border: "1px solid #ddd" }}>Nom</th>
            <th style={{ padding: "10px", border: "1px solid #ddd" }}>
              Vendeur
            </th>
            <th style={{ padding: "10px", border: "1px solid #ddd" }}>
              Catégorie
            </th>
            <th style={{ padding: "10px", border: "1px solid #ddd" }}>Prix</th>
            <th style={{ padding: "10px", border: "1px solid #ddd" }}>Stock</th>
            <th style={{ padding: "10px", border: "1px solid #ddd" }}>
              Actions
            </th>
          </tr>
        </thead>

        <tbody>
          {products.map((p: any) => (
            <tr key={p._id}>
              <td style={{ padding: "10px", border: "1px solid #ddd" }}>
                {p.name}
              </td>

              <td style={{ padding: "10px", border: "1px solid #ddd" }}>
                {p.vendorId?.name || p.vendorId?.email || "—"}
              </td>

              <td style={{ padding: "10px", border: "1px solid #ddd" }}>
                {p.category}
              </td>

              <td style={{ padding: "10px", border: "1px solid #ddd" }}>
                {p.price} €
              </td>

              <td style={{ padding: "10px", border: "1px solid #ddd" }}>
                {p.stock}
              </td>

              <td style={{ padding: "10px", border: "1px solid #ddd" }}>
                <button
                  onClick={() => router.push(`/admin/products/${p._id}`)}
                  style={{
                    padding: "6px 12px",
                    background: "#555",
                    color: "white",
                    border: "none",
                    cursor: "pointer",
                    marginRight: "10px",
                  }}
                >
                  Éditer
                </button>

                <button
                  onClick={() => handleDelete(p._id)}
                  style={{
                    padding: "6px 12px",
                    background: "red",
                    color: "white",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  Supprimer
                </button>
              </td>
            </tr>
          ))}

          {products.length === 0 && (
            <tr>
              <td
                colSpan={6}
                style={{ padding: "15px", textAlign: "center", color: "#666" }}
              >
                Aucun produit trouvé.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
