import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function POST(req: Request) {
  const form = await req.formData();
  const id = form.get("id") as string;

  await prisma.product.delete({
    where: { id },
  });

  return NextResponse.redirect("/seller/products");
}
