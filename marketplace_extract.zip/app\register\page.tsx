"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function RegisterPage() {
  const router = useRouter();
  const [error, setError] = useState("");

  async function handleSubmit(e: any) {
    e.preventDefault();

    const form = new FormData(e.target);
    const name = form.get("name");
    const email = form.get("email");
    const password = form.get("password");

    const res = await fetch("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({ name, email, password }),
    });

    const data = await res.json();

    if (!res.ok) {
      setError(data.error);
      return;
    }

    router.push("/login");
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-white text-black">
      <form onSubmit={handleSubmit} className="p-6 border rounded w-80 bg-white">
        <h1 className="text-2xl font-bold mb-4">Créer un compte</h1>

        {error && <p className="text-red-600 mb-2">{error}</p>}

        <input
          name="name"
          placeholder="Nom"
          className="border p-2 w-full mb-3"
          required
        />

        <input
          name="email"
          placeholder="Email"
          type="email"
