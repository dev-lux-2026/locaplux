export default function Cancel() {
  return (
    <div style={{ padding: "30px" }}>
      <h1>Abonnement annulé</h1>
      <p>Aucun paiement n’a été effectué.</p>
    </div>
  );
}
