"use client";

import { useEffect, useState } from "react";
import { getCart } from "@/lib/cart";
import { useRouter } from "next/navigation";

export default function CheckoutPage() {
  const [cart, setCart] = useState<any[]>([]);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const router = useRouter();

  useEffect(() => {
    setCart(getCart());
  }, []);

  const total = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  async function handlePayment() {
    if (!name || !email || !address) {
      alert("Veuillez remplir toutes les informations.");
      return;
    }

    // 1️⃣ Créer la commande dans ta base MongoDB
    const orderRes = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        items: cart,
        total,
        customer: { name, email, address },
      }),
    });

    const orderData = await orderRes.json();

    if (!orderData.success) {
      alert("Erreur lors de la création de la commande.");
      return;
    }

    const orderId = orderData.orderId;

    // 2️⃣ Lancer Stripe Checkout
    const stripeRes = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        items: cart,
        orderId, // 🔥 envoyé dans metadata → webhook
      }),
    });

    const stripeData = await stripeRes.json();

    if (stripeData.url) {
      // 3️⃣ Nettoyer le panier local AVANT de quitter le site
      localStorage.removeItem("cart");

      // 4️⃣ Redirection vers Stripe Checkout
      window.location.href = stripeData.url;
    } else {
      alert("Erreur Stripe : impossible de rediriger vers le paiement.");
    }
  }

  return (
    <div style={{ padding: "30px", maxWidth: "900px", margin: "0 auto" }}>
      <h1>Finaliser la commande</h1>

      {cart.length === 0 && <p>Votre panier est vide.</p>}

      {cart.length > 0 && (
        <>
          <h2>Résumé du panier</h2>

          {cart.map((item) => (
            <div
              key={item._id}
              style={{
                display: "flex",
                gap: "20px",
                borderBottom: "1px solid #ddd",
                paddingBottom: "20px",
                marginBottom: "20px",
              }}
            >
              <img
                src={item.images?.[0]}
                alt={item.name}
                style={{
                  width: "120px",
                  height: "120px",
                  objectFit: "cover",
                  borderRadius: "6px",
                }}
              />

              <div>
                <h3>{item.name}</h3>
                <p>{item.price} €</p>
                <p>Quantité : {item.quantity}</p>
              </div>
            </div>
          ))}

          <h2>Total : {total} €</h2>

          <h2 style={{ marginTop: "40px" }}>Informations client</h2>

          <div style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
            <input
              type="text"
              placeholder="Nom complet"
              value={name}
              onChange={(e) => setName(e.target.value)}
              style={{ padding: "10px", border: "1px solid #ccc" }}
            />

            <input
              type="email"
              placeholder="Adresse email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={{ padding: "10px", border: "1px solid #ccc" }}
            />

            <textarea
              placeholder="Adresse complète"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              style={{ padding: "10px", border: "1px solid #ccc" }}
            />

            <button
              onClick={handlePayment}
              style={{
                padding: "15px 25px",
                background: "black",
                color: "white",
                border: "none",
                borderRadius: "6px",
                cursor: "pointer",
                marginTop: "20px",
              }}
            >
              Payer maintenant
            </button>
          </div>
        </>
      )}
    </div>
  );
}
