import { NextRequest, NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";

export const config = {
  api: {
    bodyParser: false,
  },
};

export async function POST(req: NextRequest) {
  await connectDB();

  const body = await req.text();
  const signature = req.headers.get("stripe-signature")!;

  let event;

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  switch (event.type) {
    // ---------------------------------------------------------
    // 🔥 1) Paiement d'une commande (Stripe Checkout mode=payment)
    // ---------------------------------------------------------
    case "checkout.session.completed": {
      const session = event.data.object as any;

      // --- Paiement d'une commande ---
      if (session.mode === "payment" && session.metadata?.orderId) {
        const orderId = session.metadata.orderId;

        await Order.findByIdAndUpdate(orderId, {
          isPaid: true,
          paidAt: new Date(),
          paymentIntentId: session.payment_intent,
        });

        break; // IMPORTANT : ne pas exécuter le code PRO/Boost après
      }

      // ---------------------------------------------------------
      // 🔥 2) Abonnement PRO
      // ---------------------------------------------------------
      if (session.mode === "subscription") {
        const email = session.customer_email;

        await User.findOneAndUpdate(
          { email },
          {
            isPro: true,
            subscriptionId: session.subscription,
            subscriptionStatus: "active",
            commissionRate: 0.06,
          }
        );

        break;
      }

      // ---------------------------------------------------------
      // 🔥 3) Boost produit (standard / premium)
      // ---------------------------------------------------------
      const metadata = session.metadata || {};
      const productId = metadata.productId;
      const level = metadata.level;

      if (productId && level) {
        const now = new Date();
        let expires = new Date(now);

        if (level === "standard") {
          expires.setDate(now.getDate() + 1); // 24h
        }
        if (level === "premium") {
          expires.setDate(now.getDate() + 7); // 7 jours
        }

        await Product.findByIdAndUpdate(productId, {
          boostLevel: level,
          boostExpiresAt: expires,
        });
      }

      break;
    }

    // ---------------------------------------------------------
    // 🔥 4) Abonnement PRO résilié
    // ---------------------------------------------------------
    case "customer.subscription.deleted": {
      const subscription = event.data.object as any;

      await User.findOneAndUpdate(
        { subscriptionId: subscription.id },
        {
          isPro: false,
          subscriptionStatus: "canceled",
          commissionRate: 0.10,
        }
      );

      break;
    }
  }

  return NextResponse.json({ received: true });
}
