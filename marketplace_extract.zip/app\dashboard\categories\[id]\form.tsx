"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function EditCategoryForm({ category }: any) {
  const router = useRouter();
  const [name, setName] = useState(category.name);

  async function handleSubmit(e: any) {
    e.preventDefault();

    await fetch(`/api/categories/${category.id}`, {
      method: "PUT",
      body: JSON.stringify({ name }),
    });

    router.push("/dashboard/categories");
  }

  async function handleDelete() {
    await fetch(`/api/categories/${category.id}`, {
      method: "DELETE",
    });

    router.push("/dashboard/categories");
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <input
        type="text"
        className="w-full p-3 border rounded"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <div className="flex gap-4">
        <button type="submit" className="px-4 py-2 bg-black text-white rounded">
          Enregistrer
        </button>

        <button
          type="button"
          onClick={handleDelete}
          className="px-4 py-2 bg-red-600 text-white rounded"
        >
          Supprimer
        </button>
      </div>
    </form>
  );
}
