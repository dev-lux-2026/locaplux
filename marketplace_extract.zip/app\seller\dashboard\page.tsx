import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export default async function SellerDashboard() {
  const session = await getServerSession(authOptions);

  if (!session || !session.user) {
    return (
      <div style={{ padding: "30px" }}>
        <h1>Accès refusé</h1>
        <p>Vous devez être connecté pour accéder au tableau de bord vendeur.</p>
      </div>
    );
  }

  const vendorId = session.user.id;

  // Charger les infos vendeur
  const vendor = await fetch(
    `http://localhost:3000/api/vendors/${vendorId}`,
    { cache: "no-store" }
  ).then((r) => r.json());

  // Charger les produits du vendeur
  const products = await fetch(
    `http://localhost:3000/api/products?vendorId=${vendorId}`,
    { cache: "no-store" }
  ).then((r) => r.json());

  const total = products.length;
  const boosted = products.filter((p: any) => p.boostLevel !== "none").length;

  return (
    <div style={{ padding: "30px", maxWidth: "1000px", margin: "0 auto" }}>
      <h1>Tableau de bord vendeur</h1>

      {/* OVERVIEW */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
          gap: "20px",
          marginTop: "20px",
        }}
      >
        <div style={card}>
          <h3>Produits</h3>
          <p style={big}>{total}</p>
        </div>

        <div style={card}>
          <h3>Boosts actifs</h3>
          <p style={big}>{boosted}</p>
        </div>

        <div style={card}>
          <h3>Statut vendeur</h3>
          <p style={big}>{vendor.isPro ? "PRO" : "Particulier"}</p>
        </div>
      </div>

      {/* ACTIONS */}
      <div style={{ marginTop: "30px", display: "flex", gap: "15px" }}>
        <Link href="/seller/products" style={button}>
          Gérer mes produits
        </Link>

        <Link href="/seller/profile" style={button}>
          Modifier mon profil
        </Link>

        <Link href="/seller/boosts" style={button}>
          Boost Center
        </Link>

        <Link href="/seller/orders" style={button}>
          Mes commandes
        </Link>
      </div>
    </div>
  );
}

const card = {
  border: "1px solid #ddd",
  padding: "20px",
  borderRadius: "8px",
  background: "white",
};

const big = {
  fontSize: "28px",
  fontWeight: "bold",
  margin: 0,
};

const button = {
  padding: "12px 20px",
  background: "black",
  color: "white",
  borderRadius: "6px",
  textDecoration: "none",
};
