import Link from "next/link";

export default async function CategoriesPage() {
  // Charger toutes les catégories via l’API
  const categories = await fetch("http://localhost:3000/api/categories", {
    cache: "no-store",
  }).then((r) => r.json());

  // Charger tous les produits via l’API
  const products = await fetch("http://localhost:3000/api/products", {
    cache: "no-store",
  }).then((r) => r.json());

  // Construire une map slug → nombre de produits
  const countMap: Record<string, number> = {};
  products.forEach((p: any) => {
    countMap[p.categorySlug] = (countMap[p.categorySlug] || 0) + 1;
  });

  return (
    <div style={{ padding: "30px", maxWidth: "900px", margin: "0 auto" }}>
      <h1 style={{ marginBottom: "20px" }}>Toutes les catégories</h1>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
          gap: "20px",
        }}
      >
        {categories.map((cat: any) => (
          <Link
            key={cat._id}
            href={`/categories/${cat.slug}`}
            style={{
              border: "1px solid #ddd",
              padding: "20px",
              borderRadius: "8px",
              textDecoration: "none",
              color: "black",
              display: "block",
            }}
          >
            <h3 style={{ margin: 0 }}>{cat.name}</h3>

            <p style={{ marginTop: "10px", color: "#555" }}>
              {countMap[cat.slug] || 0} produit(s)
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
}
