"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function PendingCategoriesPage() {
  const { data: session, status } = useSession();
  const router = useRouter();

  const [pending, setPending] = useState([]);
  const [loading, setLoading] = useState(false);

  // Redirection si pas admin
  useEffect(() => {
    if (status === "loading") return;
    if (!session || session.user.role !== "admin") {
      router.push("/login");
    }
  }, [session, status, router]);

  const loadPending = async () => {
    const res = await fetch("/api/pending-categories");
    const data = await res.json();
    setPending(data);
  };

  useEffect(() => {
    loadPending();
  }, []);

  const handleAccept = async (id: string) => {
    if (!confirm("Accepter cette catégorie ?")) return;
    setLoading(true);

    const res = await fetch("/api/pending-categories/accept", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });

    setLoading(false);

    if (res.ok) {
      loadPending();
    } else {
      const error = await res.json();
      alert(error.error || "Erreur");
    }
  };

  const handleReject = async (id: string) => {
    if (!confirm("Rejeter cette catégorie ?")) return;

    const res = await fetch("/api/pending-categories/reject", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });

    if (res.ok) {
      loadPending();
    } else {
      const error = await res.json();
      alert(error.error || "Erreur");
    }
  };

  return (
    <div style={{ padding: "30px" }}>
      <h1 style={{ fontSize: "26px", marginBottom: "20px" }}>
        Catégories proposées par les vendeurs
      </h1>

      <button
        onClick={() => router.push("/admin/categories")}
        style={{
          marginBottom: "20px",
          padding: "8px 16px",
          background: "#555",
          color: "white",
          border: "none",
          cursor: "pointer",
        }}
      >
        Retour aux catégories
      </button>

      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          marginTop: "10px",
        }}
      >
        <thead>
          <tr style={{ background: "#f5f5f5" }}>
            <th style={{ padding: "10px", border: "1px solid #ddd" }}>Nom</th>
            <th style={{ padding: "10px", border: "1px solid #ddd" }}>
              Vendeur
            </th>
            <th style={{ padding: "10px", border: "1px solid #ddd" }}>
              Produit
            </th>
            <th style={{ padding: "10px", border: "1px solid #ddd" }}>
              Statut
            </th>
            <th style={{ padding: "10px", border: "1px solid #ddd" }}>
              Actions
            </th>
          </tr>
        </thead>
        <tbody>
          {pending.map((item: any) => (
            <tr key={item._id}>
              <td style={{ padding: "10px", border: "1px solid #ddd" }}>
                {item.name}
              </td>
              <td style={{ padding: "10px", border: "1px solid #ddd" }}>
                {item.vendorId?.name || item.vendorId?.email || "—"}
              </td>
              <td style={{ padding: "10px", border: "1px solid #ddd" }}>
                {item.productId?.name || "—"}
              </td>
              <td style={{ padding: "10px", border: "1px solid #ddd" }}>
                {item.status}
              </td>
              <td style={{ padding: "10px", border: "1px solid #ddd" }}>
                <button
                  onClick={() => handleAccept(item._id)}
                  disabled={loading}
                  style={{
                    padding: "6px 12px",
                    background: "green",
                    color: "white",
                    border: "none",
                    cursor: "pointer",
                    marginRight: "10px",
                  }}
                >
                  Accepter
                </button>
                <button
                  onClick={() => handleReject(item._id)}
                  style={{
                    padding: "6px 12px",
                    background: "red",
                    color: "white",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  Rejeter
                </button>
              </td>
            </tr>
          ))}

          {pending.length === 0 && (
            <tr>
              <td
                colSpan={5}
                style={{ padding: "15px", textAlign: "center", color: "#666" }}
              >
                Aucune catégorie proposée pour le moment.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
