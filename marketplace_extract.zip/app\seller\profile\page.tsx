"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function SellerProfilePage() {
  const router = useRouter();

  const [loading, setLoading] = useState(true);

  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState("");
  const [description, setDescription] = useState("");
  const [isPro, setIsPro] = useState(false);
  const [deliveryRadius, setDeliveryRadius] = useState("");
  const [address, setAddress] = useState("");

  const [vendorId, setVendorId] = useState("");

  // Charger les infos du vendeur
  useEffect(() => {
    async function loadVendor() {
      const sessionRes = await fetch("/api/auth/session");
      const session = await sessionRes.json();

      if (!session?.user?.id) {
        router.push("/login");
        return;
      }

      const id = session.user.id;
      setVendorId(id);

      const vendorRes = await fetch(
        `http://localhost:3000/api/vendors/${id}`,
        { cache: "no-store" }
      );
      const vendor = await vendorRes.json();

      setName(vendor.name || "");
      setAvatar(vendor.avatar || "");
      setDescription(vendor.description || "");
      setIsPro(vendor.isPro || false);
      setDeliveryRadius(vendor.deliveryRadius || "");
      setAddress(vendor.address || "");

      setLoading(false);
    }

    loadVendor();
  }, [router]);

  async function handleSubmit(e: any) {
    e.preventDefault();

    const res = await fetch(`/api/vendors/${vendorId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        avatar,
        description,
        isPro,
        deliveryRadius: deliveryRadius ? Number(deliveryRadius) : null,
        address,
      }),
    });

    if (res.ok) {
      alert("Profil mis à jour avec succès !");
      router.refresh();
    } else {
      alert("Erreur lors de la mise à jour du profil.");
    }
  }

  if (loading) {
    return <div style={{ padding: "30px" }}>Chargement...</div>;
  }

  return (
    <div style={{ padding: "30px", maxWidth: "700px", margin: "0 auto" }}>
      <h1>Mon profil vendeur</h1>

      <form onSubmit={handleSubmit} style={{ marginTop: "20px" }}>
        {/* NOM */}
        <label>Nom du vendeur</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          style={input}
        />

        {/* AVATAR */}
        <label>Avatar (URL)</label>
        <input
          type="text"
          value={avatar}
          onChange={(e) => setAvatar(e.target.value)}
          style={input}
        />

        {avatar && (
          <img
            src={avatar}
            alt="avatar"
            style={{
              width: "100px",
              height: "100px",
              objectFit: "cover",
              borderRadius: "50%",
              marginBottom: "15px",
            }}
          />
        )}

        {/* DESCRIPTION */}
        <label>Description</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          style={{ ...input, height: "120px" }}
        />

        {/* STATUT PRO */}
        <label style={{ marginTop: "20px", display: "block" }}>
          Statut vendeur
        </label>
        <select
          value={isPro ? "pro" : "particulier"}
          onChange={(e) => setIsPro(e.target.value === "pro")}
          style={input}
        >
          <option value="particulier">Particulier</option>
          <option value="pro">PRO</option>
        </select>

        {/* RAYON DE LIVRAISON */}
        <label>Rayon de livraison (km)</label>
        <input
          type="number"
          value={deliveryRadius}
          onChange={(e) => setDeliveryRadius(e.target.value)}
          style={input}
        />

        {/* ADRESSE */}
        <label>Adresse (optionnel)</label>
        <input
          type="text"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          style={input}
        />

        {/* SUBMIT */}
        <button
          type="submit"
          style={{
            marginTop: "20px",
            padding: "12px 20px",
            background: "black",
            color: "white",
            borderRadius: "6px",
            cursor: "pointer",
          }}
        >
          Enregistrer les modifications
        </button>
      </form>
    </div>
  );
}

const input = {
  width: "100%",
  padding: "10px",
  border: "1px solid #ddd",
  borderRadius: "6px",
  marginTop: "5px",
  marginBottom: "15px",
};
