import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";

export async function POST(req: Request) {
  await connectDB();

  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token || token.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await req.json();

  const pending = await PendingCategory.findById(id);
  if (!pending) {
    return NextResponse.json({ error: "Catégorie introuvable" }, { status: 404 });
  }

  pending.status = "rejected";
  await pending.save();

  return NextResponse.json({ message: "Catégorie rejetée" });
}
