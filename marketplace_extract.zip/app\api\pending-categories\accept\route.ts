import { NextResponse } from "next/server";
import slugify from "slugify";
import { getToken } from "next-auth/jwt";

export async function POST(req: Request) {
  await connectDB();

  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token || token.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await req.json();

  const pending = await PendingCategory.findById(id);
  if (!pending) {
    return NextResponse.json({ error: "Catégorie introuvable" }, { status: 404 });
  }

  const slug = slugify(pending.name, { lower: true });

  // Créer la catégorie officielle
  const category = await Category.create({
    name: pending.name,
    slug,
  });

  // Mettre à jour tous les produits liés
  await Product.updateMany(
    { category: pending.name },
    { category: pending.name, categorySlug: slug }
  );

  // Marquer comme acceptée
  pending.status = "accepted";
  await pending.save();

  return NextResponse.json({ message: "Catégorie acceptée", category });
}
