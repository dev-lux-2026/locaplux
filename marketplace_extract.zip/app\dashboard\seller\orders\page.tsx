"use client";

import { useEffect, useState } from "react";

export default function SellerOrdersPage() {
  const [orders, setOrders] = useState([]);

  const loadOrders = () => {
    fetch("/api/orders/seller")
      .then((res) => res.json())
      .then((data) => setOrders(data));
  };

  useEffect(() => {
    loadOrders();
  }, []);

  const updateStatus = async (id: string, status: string) => {
    await fetch(`/api/orders/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });

    loadOrders();
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Commandes reçues</h1>

      {orders.length === 0 && <p>Aucune commande reçue.</p>}

      {orders.map((order: any) => (
        <div key={order._id} className="border p-4 rounded mb-4">
          <h2 className="font-semibold">Commande #{order._id}</h2>
          <p>Status : {order.status}</p>

          <div className="mt-2">
            {order.items.map((item: any) => (
              <div key={item._id} className="flex justify-between">
                <span>{item.title}</span>
                <span>{item.quantity} × {item.price} €</span>
              </div>
            ))}
          </div>

          <div className="flex gap-2 mt-4">
            <button
              onClick={() => updateStatus(order._id, "shipped")}
              className="bg-blue-600 text-white px-3 py-1 rounded"
            >
              Expédiée
            </button>

            <button
              onClick={() => updateStatus(order._id, "delivered")}
              className="bg-green-600 text-white px-3 py-1 rounded"
            >
              Livrée
            </button>

            <button
              onClick={() => updateStatus(order._id, "cancelled")}
              className="bg-red-600 text-white px-3 py-1 rounded"
            >
              Annulée
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
