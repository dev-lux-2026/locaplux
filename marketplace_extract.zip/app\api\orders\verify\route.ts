import { NextResponse } from "next/server";
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2023-10-16",
});

export async function GET(req: Request) {
  try {
    await connectDB();

    const { searchParams } = new URL(req.url);
    const sessionId = searchParams.get("session_id");

    if (!sessionId) {
      return NextResponse.json({ error: "Missing session_id" }, { status: 400 });
    }

    const session = await stripe.checkout.sessions.retrieve(sessionId);

    const orderId = session.metadata?.orderId;

    if (!orderId) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    const order = await Order.findById(orderId).lean();

    return NextResponse.json({ order });
  } catch (error) {
    console.error("Erreur verify order :", error);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
