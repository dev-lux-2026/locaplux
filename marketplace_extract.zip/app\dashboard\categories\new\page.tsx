"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewCategoryPage() {
  const router = useRouter();
  const [name, setName] = useState("");

  async function handleSubmit(e: any) {
    e.preventDefault();

    await fetch("/api/categories", {
      method: "POST",
      body: JSON.stringify({ name }),
    });

    router.push("/dashboard/categories");
  }

  return (
    <div className="space-y-6 max-w-lg">
      <h1 className="text-2xl font-bold">Nouvelle catégorie</h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Nom de la catégorie"
          className="w-full p-3 border rounded"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <button
          type="submit"
          className="px-4 py-2 bg-black text-white rounded"
        >
          Créer
        </button>
      </form>
    </div>
  );
}
