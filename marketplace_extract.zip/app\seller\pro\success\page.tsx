export default function Success() {
  return (
    <div style={{ padding: "30px" }}>
      <h1>Abonnement activé 🎉</h1>
      <p>Vous êtes maintenant Vendeur PRO.</p>
    </div>
  );
}
