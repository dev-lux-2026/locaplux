import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import slugify from "slugify";

interface Props {
  params: { id: string };
}

export default async function EditProductPage({ params }: Props) {
  const session = await getServerSession();
  if (!session) redirect("/login");

  const product = await prisma.product.findUnique({
    where: { id: params.id },
  });

  if (!product) redirect("/dashboard/products");

  return (
    <div className="space-y-8 text-gray-900">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Modifier le produit</h1>
        <Link href="/dashboard/products" className="px-4 py-2 bg-gray-200 rounded">
          Retour
        </Link>
      </div>

      <form
        action={async (formData) => {
          "use server";

          const name = formData.get("name") as string;
          const slug = slugify(name, { lower: true });
          const price = Number(formData.get("price"));
          const stock = Number(formData.get("stock"));
          const description = formData.get("description") as string;

          await prisma.product.update({
            where: { id: params.id },
            data: { name, slug, price, stock, description },
          });

          redirect("/dashboard/products");
        }}
        className="space-y-4 bg-white p-6 rounded border"
      >
        <div>
          <label className="block text-sm font-medium">Nom</label>
          <input name="name" defaultValue={product.name} className="mt-1 w-full border rounded px-3 py-2" required />
        </div>

        <div>
          <label className="block text-sm font-medium">Prix (€)</label>
          <input type="number" name="price" defaultValue={product.price} className="mt-1 w-full border rounded px-3 py-2" required />
        </div>

        <div>
          <label className="block text-sm font-medium">Stock</label>
          <input type="number" name="stock" defaultValue={product.stock} className="mt-1 w-full border rounded px-3 py-2" required />
        </div>

        <div>
          <label className="block text-sm font-medium">Description</label>
          <textarea name="description" defaultValue={product.description ?? ""} className="mt-1 w-full border rounded px-3 py-2" rows={4} />
        </div>

        <button type="submit" className="px-4 py-2 bg-black text-white rounded">
          Enregistrer
        </button>
      </form>

      <form
        action={async () => {
          "use server";
          await prisma.product.delete({ where: { id: params.id } });
          redirect("/dashboard/products");
        }}
      >
        <button type="submit" className="px-4 py-2 bg-red-600 text-white rounded">
          Supprimer
        </button>
      </form>
    </div>
  );
}
