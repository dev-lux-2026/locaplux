"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function CategoryForm({ category }: { category?: any }) {
  const router = useRouter();
  const [name, setName] = useState(category?.name || "");
  const [slug, setSlug] = useState(category?.slug || "");

  async function handleSubmit(e: any) {
    e.preventDefault();

    const method = category ? "PUT" : "POST";
    const url = category
      ? `/api/categories/${category.id}`
      : `/api/categories`;

    await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, slug }),
    });

    router.push("/admin/categories");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-w-md">
      <div>
        <label className="block font-medium">Nom</label>
        <input
          className="border p-2 w-full"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
      </div>

      <div>
        <label className="block font-medium">Slug</label>
        <input
          className="border p-2 w-full"
          value={slug}
          onChange={(e) => setSlug(e.target.value)}
          required
        />
      </div>

      <button className="bg-blue-600 text-white px-4 py-2 rounded">
        {category ? "Mettre à jour" : "Créer"}
      </button>
    </form>
  );
}
