"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function EditProductPage({ params }: any) {
  const router = useRouter();
  const { productId } = params;

  const [loading, setLoading] = useState(true);

  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [originalPrice, setOriginalPrice] = useState("");
  const [description, setDescription] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const [imageInput, setImageInput] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [boostLevel, setBoostLevel] = useState("none");

  const [categories, setCategories] = useState<any[]>([]);

  // Charger les catégories + le produit
  useEffect(() => {
    async function loadData() {
      const catRes = await fetch("http://localhost:3000/api/categories");
      const catData = await catRes.json();
      setCategories(catData);

      const prodRes = await fetch(
        `http://localhost:3000/api/products/${productId}`
      );
      const product = await prodRes.json();

      setName(product.name);
      setPrice(product.price);
      setOriginalPrice(product.originalPrice || "");
      setDescription(product.description);
      setImages(product.images || []);
      setCategoryId(product.categoryId);
      setBoostLevel(product.boostLevel);

      setLoading(false);
    }

    loadData();
  }, [productId]);

  async function handleSubmit(e: any) {
    e.preventDefault();

    const res = await fetch(`/api/products/${productId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        price: Number(price),
        originalPrice: originalPrice ? Number(originalPrice) : null,
        description,
        images,
        categoryId,
        boostLevel,
      }),
    });

    if (res.ok) {
      router.push("/seller/products");
    } else {
      alert("Erreur lors de la mise à jour du produit.");
    }
  }

  function addImage() {
    if (!imageInput.trim()) return;
    setImages([...images, imageInput.trim()]);
    setImageInput("");
  }

  function removeImage(index: number) {
    setImages(images.filter((_, i) => i !== index));
  }

  if (loading) {
    return <div style={{ padding: "30px" }}>Chargement...</div>;
  }

  return (
    <div style={{ padding: "30px", maxWidth: "700px", margin: "0 auto" }}>
      <h1>Modifier le produit</h1>

      <form onSubmit={handleSubmit} style={{ marginTop: "20px" }}>
        {/* NOM */}
        <label>Nom du produit</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          style={input}
        />

        {/* PRIX */}
        <label>Prix (€)</label>
        <input
          type="number"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          required
          style={input}
        />

        {/* PRIX ORIGINAL */}
        <label>Prix original (optionnel)</label>
        <input
          type="number"
          value={originalPrice}
          onChange={(e) => setOriginalPrice(e.target.value)}
          style={input}
        />

        {/* DESCRIPTION */}
        <label>Description</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
          style={{ ...input, height: "120px" }}
        />

        {/* IMAGES */}
        <label>Images (URL)</label>
        <div style={{ display: "flex", gap: "10px" }}>
          <input
            type="text"
            value={imageInput}
            onChange={(e) => setImageInput(e.target.value)}
            style={{ ...input, flex: 1 }}
          />
          <button
            type="button"
            onClick={addImage}
            style={{
              padding: "10px 15px",
              background: "#0070f3",
              color: "white",
              borderRadius: "6px",
            }}
          >
            Ajouter
          </button>
        </div>

        {images.length > 0 && (
          <div style={{ marginTop: "10px" }}>
            {images.map((img, i) => (
              <div
                key={i}
                style={{
                  display: "inline-block",
                  marginRight: "10px",
                  position: "relative",
                }}
              >
                <img
                  src={img}
                  alt="preview"
                  style={{
                    width: "100px",
                    height: "100px",
                    objectFit: "cover",
                    borderRadius: "6px",
                  }}
                />
                <button
                  type="button"
                  onClick={() => removeImage(i)}
                  style={{
                    position: "absolute",
                    top: "-5px",
                    right: "-5px",
                    background: "red",
                    color: "white",
                    borderRadius: "50%",
                    width: "22px",
                    height: "22px",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}

        {/* CATÉGORIE */}
        <label style={{ marginTop: "20px", display: "block" }}>
          Catégorie
        </label>
        <select
          value={categoryId}
          onChange={(e) => setCategoryId(e.target.value)}
          required
          style={input}
        >
          <option value="">Sélectionner une catégorie</option>
          {categories.map((c) => (
            <option key={c._id} value={c._id}>
              {c.name}
            </option>
          ))}
        </select>

        {/* BOOST */}
        <label style={{ marginTop: "20px", display: "block" }}>
          Niveau de Boost
        </label>
        <select
          value={boostLevel}
          onChange={(e) => setBoostLevel(e.target.value)}
          style={input}
        >
          <option value="none">Aucun</option>
          <option value="standard">Standard</option>
          <option value="premium">Premium</option>
        </select>

        {/* SUBMIT */}
        <button
          type="submit"
          style={{
            marginTop: "20px",
            padding: "12px 20px",
            background: "black",
            color: "white",
            borderRadius: "6px",
            cursor: "pointer",
          }}
        >
          Enregistrer les modifications
        </button>
      </form>
    </div>
  );
}

const input = {
  width: "100%",
  padding: "10px",
  border: "1px solid #ddd",
  borderRadius: "6px",
  marginTop: "5px",
  marginBottom: "15px",
};
