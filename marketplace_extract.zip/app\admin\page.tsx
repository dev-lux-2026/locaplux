import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export default async function AdminPage() {
  const session = await getServerSession();
  if (!session) redirect("/login");
  if (session.user.role !== "admin") redirect("/dashboard");

  const users = await prisma.user.findMany({
    where: { role: "user" },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="p-10 space-y-6">
      <h1 className="text-3xl font-bold">Validation des vendeurs</h1>

      <div className="space-y-4">
        {users.length === 0 && (
          <p>Aucune demande en attente.</p>
        )}

        {users.map((u) => (
          <form
            key={u.id}
            action={`/api/admin/validate-seller?id=${u.id}`}
            method="POST"
            className="p-4 border rounded bg-white flex items-center justify-between"
          >
            <div>
              <p className="font-semibold">{u.name}</p>
              <p className="text-gray-600">{u.email}</p>
            </div>

            <button
              type="submit"
              className="px-4 py-2 bg-green-600 text-white rounded"
            >
              Valider vendeur
            </button>
          </form>
        ))}
      </div>
    </div>
  );
}
