import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export default async function SellerBoosts() {
  const session = await getServerSession();
  if (!session) redirect("/login");
  if (session.user.role !== "seller") redirect("/dashboard");

  const boosts = await prisma.boost.findMany({
    orderBy: { price: "asc" },
  });

  return (
    <div className="p-10 space-y-6">
      <h1 className="text-2xl font-bold">Boosts disponibles</h1>

      <div className="grid grid-cols-3 gap-6">
        {boosts.map((b) => (
          <div key={b.id} className="p-6 border rounded bg-white shadow">
            <h2 className="text-xl font-semibold">{b.title}</h2>
            <p className="text-gray-600">{b.duration} jours</p>
            <p className="text-lg font-bold mt-2">{b.price} €</p>

            <button className="mt-4 px-4 py-2 bg-green-600 text-white rounded">
              Acheter
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
