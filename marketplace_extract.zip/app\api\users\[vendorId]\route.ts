import { NextResponse } from "next/server";
import mongoose from "mongoose";

export async function GET(
  req: Request,
  { params }: { params: { vendorId: string } }
) {
  try {
    await connectDB();

    // Vérifier ID MongoDB
    if (!mongoose.Types.ObjectId.isValid(params.vendorId)) {
      return NextResponse.json({ error: "ID invalide" }, { status: 400 });
    }

    // Charger le vendeur
    const vendor = await User.findById(params.vendorId).select(
      "name avatar isPro deliveryRadius address"
    );

    if (!vendor) {
      return NextResponse.json(
        { error: "Vendeur introuvable" },
        { status: 404 }
      );
    }

    return NextResponse.json(vendor);
  } catch (error) {
    return NextResponse.json(
      { error: "Erreur lors du chargement du vendeur" },
      { status: 500 }
    );
  }
}
