import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";

export default async function NewProductPage() {
  const session = await getServerSession();
  if (!session) redirect("/login");
  if (session.user.role !== "seller") redirect("/dashboard");

  return (
    <div className="p-10 space-y-6 max-w-xl">
      <h1 className="text-2xl font-bold">Ajouter un produit</h1>

      <form action="/api/products/create" method="POST" className="space-y-4">
        <input
          name="name"
          placeholder="Nom du produit"
          className="border p-2 w-full"
          required
        />

        <textarea
          name="description"
          placeholder="Description"
          className="border p-2 w-full"
        />

        <input
          name="price"
          type="number"
          placeholder="Prix (€)"
          className="border p-2 w-full"
          required
        />

        <input
          name="stock"
          type="number"
          placeholder="Stock"
          className="border p-2 w-full"
          required
        />

        <button className="px-4 py-2 bg-blue-600 text-white rounded">
          Créer
        </button>
      </form>
    </div>
  );
}
