import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import { stripe } from "@/lib/stripe";

export async function POST(req: NextRequest) {
  await connectDB();

  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });

  if (!token || token.role !== "vendor") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { productId, level } = await req.json();

  const product = await Product.findOne({
    _id: productId,
    vendorId: token.id,
  });

  if (!product) {
    return NextResponse.json(
      { error: "Produit introuvable ou non autorisé" },
      { status: 404 }
    );
  }

  let priceId = "";
  if (level === "standard") priceId = process.env.STRIPE_BOOST_STANDARD_PRICE_ID!;
  if (level === "premium") priceId = process.env.STRIPE_BOOST_PREMIUM_PRICE_ID!;
  if (!priceId) {
    return NextResponse.json({ error: "Niveau de boost invalide" }, { status: 400 });
  }

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    customer_email: token.email as string,
    line_items: [
      {
        price: priceId,
        quantity: 1,
      },
    ],
    metadata: {
      productId: product._id.toString(),
      level,
    },
    success_url: "http://localhost:3000/vendor/products?boost=success",
    cancel_url: "http://localhost:3000/vendor/products?boost=cancel",
  });

  return NextResponse.json({ url: session.url });
}
