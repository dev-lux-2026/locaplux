"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function BecomeProPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async () => {
    setLoading(true);

    const res = await fetch("/api/stripe/subscribe", {
      method: "POST",
    });

    const data = await res.json();
    window.location.href = data.url;
  };

  if (!session?.user) return null;

  return (
    <div style={{ padding: "30px" }}>
      <h1 style={{ fontSize: "28px", marginBottom: "20px" }}>
        Devenir Vendeur PRO
      </h1>

      <p style={{ marginBottom: "20px" }}>
        Passez en compte PRO et bénéficiez de :
      </p>

      <ul style={{ marginBottom: "20px" }}>
        <li>Commission réduite : 6%</li>
        <li>Mise en avant des produits</li>
        <li>Badge PRO</li>
        <li>Statistiques avancées</li>
        <li>Support prioritaire</li>
      </ul>

      <button
        onClick={handleSubscribe}
        disabled={loading}
        style={{
          padding: "12px 20px",
          background: "#0070f3",
          color: "white",
          border: "none",
          cursor: "pointer",
        }}
      >
        {loading ? "Redirection..." : "Passer en PRO (19€/mois)"}
      </button>
    </div>
  );
}
