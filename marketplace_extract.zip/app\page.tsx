import Link from "next/link";

export default async function HomePage() {
  await connectDB();

  // Produits boostés en premier
  const boosted = await Product.find({ boostLevel: { $ne: "none" } })
    .sort({ boostLevel: -1, createdAt: -1 })
    .limit(8)
    .lean();

  // Produits récents
  const recent = await Product.find()
    .sort({ createdAt: -1 })
    .limit(8)
    .lean();

  // Catégories
  const categories = await Category.find().lean();

  return (
    <div style={{ padding: "30px", maxWidth: "1100px", margin: "0 auto" }}>
      {/* HERO */}
      <div
        style={{
          padding: "40px",
          background: "#f5f5f5",
          borderRadius: "12px",
          marginBottom: "40px",
          textAlign: "center",
        }}
      >
        <h1 style={{ fontSize: "32px", marginBottom: "10px" }}>
          Bienvenue sur le Marketplace
        </h1>
        <p style={{ fontSize: "18px", color: "#555" }}>
          Les meilleures affaires, les fins de série, les produits d’exposition
          et les retours clients — au meilleur prix.
        </p>
      </div>

      {/* CATÉGORIES */}
      <h2 style={{ marginBottom: "20px" }}>Catégories</h2>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
          gap: "20px",
          marginBottom: "40px",
        }}
      >
        {categories.map((cat: any) => (
          <Link
            key={cat._id}
            href={`/category/${cat.slug}`}
            style={{
              border: "1px solid #ddd",
              padding: "20px",
              borderRadius: "8px",
              textDecoration: "none",
              color: "black",
              textAlign: "center",
            }}
          >
            <h3 style={{ margin: 0 }}>{cat.name}</h3>
          </Link>
        ))}
      </div>

      {/* PRODUITS BOOSTÉS */}
      {boosted.length > 0 && (
        <>
          <h2 style={{ marginBottom: "20px" }}>Produits Boostés</h2>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
              gap: "20px",
              marginBottom: "40px",
            }}
          >
            {boosted.map((p: any) => (
              <Link
                key={p._id}
                href={`/product/${p.slug}`}
                style={{
                  border: "1px solid #ddd",
                  padding: "15px",
                  borderRadius: "8px",
                  textDecoration: "none",
                  color: "black",
                }}
              >
                <img
                  src={p.images?.[0]}
                  alt={p.name}
                  style={{
                    width: "100%",
                    height: "150px",
                    objectFit: "cover",
                    borderRadius: "6px",
                  }}
                />

                <h3 style={{ marginTop: "10px" }}>{p.name}</h3>

                <p style={{ fontWeight: "bold" }}>{p.price} €</p>

                {p.boostLevel !== "none" && (
                  <span
                    style={{
                      background:
                        p.boostLevel === "premium" ? "purple" : "#0070f3",
                      color: "white",
                      padding: "4px 8px",
                      borderRadius: "4px",
                      fontSize: "12px",
                    }}
                  >
                    BOOST {p.boostLevel.toUpperCase()}
                  </span>
                )}
              </Link>
            ))}
          </div>
        </>
      )}

      {/* PRODUITS RÉCENTS */}
      <h2 style={{ marginBottom: "20px" }}>Nouveautés</h2>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
          gap: "20px",
        }}
      >
        {recent.map((p: any) => (
          <Link
            key={p._id}
            href={`/product/${p.slug}`}
            style={{
              border: "1px solid #ddd",
              padding: "15px",
              borderRadius: "8px",
              textDecoration: "none",
              color: "black",
            }}
          >
            <img
              src={p.images?.[0]}
              alt={p.name}
              style={{
                width: "100%",
                height: "150px",
                objectFit: "cover",
                borderRadius: "6px",
              }}
            />

            <h3 style={{ marginTop: "10px" }}>{p.name}</h3>
            <p style={{ fontWeight: "bold" }}>{p.price} €</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
