import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import slugify from "slugify";

export default async function NewProductPage() {
  const session = await getServerSession();
  if (!session) redirect("/login");

  return (
    <div className="space-y-8 text-gray-900">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Nouveau produit</h1>
        <Link href="/dashboard/products" className="px-4 py-2 bg-gray-200 rounded">
          Retour
        </Link>
      </div>

      <form
        action={async (formData) => {
          "use server";

          const name = formData.get("name") as string;
          const slug = slugify(name, { lower: true });
          const price = Number(formData.get("price"));
          const stock = Number(formData.get("stock"));
          const description = formData.get("description") as string;

          await prisma.product.create({
            data: {
              name,
              slug,
              price,
              stock,
              description,
            },
          });

          redirect("/dashboard/products");
        }}
        className="space-y-4 bg-white p-6 rounded border"
      >
        <div>
          <label className="block text-sm font-medium">Nom</label>
          <input name="name" className="mt-1 w-full border rounded px-3 py-2" required />
        </div>

        <div>
          <label className="block text-sm font-medium">Prix (€)</label>
          <input type="number" name="price" className="mt-1 w-full border rounded px-3 py-2" required />
        </div>

        <div>
          <label className="block text-sm font-medium">Stock</label>
          <input type="number" name="stock" className="mt-1 w-full border rounded px-3 py-2" required />
        </div>

        <div>
          <label className="block text-sm font-medium">Description</label>
          <textarea name="description" className="mt-1 w-full border rounded px-3 py-2" rows={4} />
        </div>

        <button type="submit" className="px-4 py-2 bg-black text-white rounded">
          Créer
        </button>
      </form>
    </div>
  );
}
