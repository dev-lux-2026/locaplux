import Link from "next/link";

export default function ProductCard({ product }: any) {
  return (
    <div style={{ position: "relative", border: "1px solid #ddd", padding: "10px" }}>
      
      {/* 🔥 Badge BOOST */}
      {product.boostLevel !== "none" && (
        <div
          style={{
            position: "absolute",
            top: "10px",
            left: "10px",
            background: product.boostLevel === "premium" ? "purple" : "#0070f3",
            color: "white",
            padding: "4px 8px",
            borderRadius: "4px",
            fontSize: "12px",
            fontWeight: "bold",
          }}
        >
          BOOST
        </div>
      )}

      <img
        src={product.images?.[0]}
        alt={product.name}
        style={{ width: "100%", height: "200px", objectFit: "cover" }}
      />

      <h3>{product.name}</h3>

      <p>{product.price} €</p>

      {/* 🔥 Badge PRO vendeur */}
      {product.vendor?.isPro && (
        <span
          style={{
            background: "gold",
            color: "black",
            padding: "3px 6px",
            borderRadius: "4px",
            fontSize: "11px",
            fontWeight: "bold",
          }}
        >
          PRO
        </span>
      )}

      <Link href={`/product/${product._id}`}>Voir le produit</Link>
    </div>
  );
}
