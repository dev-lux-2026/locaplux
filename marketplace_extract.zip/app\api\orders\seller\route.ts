import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";

export async function GET(req: Request) {
  try {
    await connectDB();

    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });

    if (!token || token.role !== "seller") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Récupérer les produits du vendeur
    const sellerProducts = await Product.find({ seller: token.sub });

    const sellerProductIds = sellerProducts.map((p) => p._id.toString());

    // Récupérer les commandes contenant ces produits
    const orders = await Order.find({
      "items._id": { $in: sellerProductIds },
    });

    return NextResponse.json(orders);
  } catch (error) {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
