import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";

// GET : récupérer toutes les catégories proposées
export async function GET() {
  await connectDB();
  const pending = await PendingCategory.find()
    .populate("vendorId", "name email")
    .populate("productId", "name");

  return NextResponse.json(pending);
}
