import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    await connectDB();

    const { items, total, customer } = await req.json();

    if (!items || items.length === 0) {
      return NextResponse.json({ error: "Panier vide" }, { status: 400 });
    }

    if (!customer || !customer.name || !customer.email || !customer.address) {
      return NextResponse.json({ error: "Informations client manquantes" }, { status: 400 });
    }

    // 🔥 Création de la commande dans MongoDB
    const order = await Order.create({
      items,
      total,
      customer,
      status: "pending",     // statut interne (vendeur)
      isPaid: false,         // Stripe mettra à jour
      paidAt: null,          // Stripe mettra à jour
      paymentIntentId: null, // Stripe mettra à jour
    });

    return NextResponse.json({
      success: true,
      orderId: order._id.toString(),
    });
  } catch (error) {
    console.error("Order creation error:", error);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
