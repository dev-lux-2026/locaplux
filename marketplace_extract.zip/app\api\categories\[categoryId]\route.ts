import { NextResponse } from "next/server";
import slugify from "slugify";
import { getToken } from "next-auth/jwt";
import mongoose from "mongoose";

// GET : récupérer une catégorie par ID
export async function GET(
  req: Request,
  { params }: { params: { categoryId: string } }
) {
  await connectDB();

  if (!mongoose.Types.ObjectId.isValid(params.categoryId)) {
    return NextResponse.json({ error: "ID invalide" }, { status: 400 });
  }

  const category = await Category.findById(params.categoryId);

  if (!category) {
    return NextResponse.json(
      { error: "Catégorie introuvable" },
      { status: 404 }
    );
  }

  return NextResponse.json(category);
}

// PUT : modifier une catégorie (admin uniquement)
export async function PUT(
  req: Request,
  { params }: { params: { categoryId: string } }
) {
  try {
    await connectDB();

    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
    if (!token || token.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    if (!mongoose.Types.ObjectId.isValid(params.categoryId)) {
      return NextResponse.json({ error: "ID invalide" }, { status: 400 });
    }

    const { name } = await req.json();

    if (!name) {
      return NextResponse.json(
        { error: "Le nom est requis" },
        { status: 400 }
      );
    }

    const newSlug = slugify(name, { lower: true, strict: true });

    const category = await Category.findById(params.categoryId);
    if (!category) {
      return NextResponse.json(
        { error: "Catégorie introuvable" },
        { status: 404 }
      );
    }

    // 🔥 Mise à jour des produits liés
    await Product.updateMany(
      { categoryId: category._id },
      { category: name, categorySlug: newSlug }
    );

    category.name = name;
    category.slug = newSlug;

    await category.save();

    return NextResponse.json(category);
  } catch (error) {
    return NextResponse.json(
      { error: "Erreur lors de la mise à jour" },
      { status: 500 }
    );
  }
}

// DELETE : supprimer une catégorie (admin uniquement)
export async function DELETE(
  req: Request,
  { params }: { params: { categoryId: string } }
) {
  try {
    await connectDB();

    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
    if (!token || token.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    if (!mongoose.Types.ObjectId.isValid(params.categoryId)) {
      return NextResponse.json({ error: "ID invalide" }, { status: 400 });
    }

    const category = await Category.findById(params.categoryId);
    if (!category) {
      return NextResponse.json(
        { error: "Catégorie introuvable" },
        { status: 404 }
      );
    }

    // 🔥 Empêcher la suppression si des produits utilisent cette catégorie
    const productCount = await Product.countDocuments({
      categoryId: category._id,
    });

    if (productCount > 0) {
      return NextResponse.json(
        { error: "Impossible de supprimer : des produits utilisent cette catégorie" },
        { status: 400 }
      );
    }

    await Category.findByIdAndDelete(params.categoryId);

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { error: "Erreur lors de la suppression" },
      { status: 500 }
    );
  }
}
