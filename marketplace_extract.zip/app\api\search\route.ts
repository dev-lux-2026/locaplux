import { NextResponse } from "next/server";

export async function GET(req: Request) {
  await connectDB();

  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q") || "";

  if (!q.trim()) {
    return NextResponse.json([]);
  }

  // Chercher les vendeurs correspondants
  const vendors = await User.find({
    name: { $regex: q, $options: "i" }
  }).select("_id");

  const vendorIds = vendors.map((v) => v._id);

  // Chercher les produits
  const products = await Product.find({
    $or: [
      { name: { $regex: q, $options: "i" } },
      { description: { $regex: q, $options: "i" } },
      { categorySlug: { $regex: q, $options: "i" } },
      { vendorId: { $in: vendorIds } }
    ]
  })
    .sort({ boostLevel: -1, createdAt: -1 })
    .lean();

  return NextResponse.json(products);
}
