"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

export default function EditCategoryPage({ params }: any) {
  const { data: session, status } = useSession();
  const router = useRouter();
  const { categoryId } = params;

  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Protection admin
  useEffect(() => {
    if (status === "loading") return;
    if (!session || session.user.role !== "admin") {
      router.push("/login");
    }
  }, [session, status, router]);

  // Charger la catégorie
  useEffect(() => {
    fetch(`/api/categories/${categoryId}`)
      .then((res) => res.json())
      .then((data) => {
        setName(data.name);
        setSlug(data.slug);
      });
  }, [categoryId]);

  // Modifier la catégorie
  const handleUpdate = async (e: any) => {
    e.preventDefault();
    setLoading(true);

    const res = await fetch(`/api/categories/${categoryId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    });

    setLoading(false);

    if (!res.ok) {
      const data = await res.json();
      setError(data.error || "Erreur");
      return;
    }

    router.push("/admin/categories");
  };

  // Supprimer la catégorie
  const handleDelete = async () => {
    if (!confirm("Supprimer cette catégorie ?")) return;

    await fetch(`/api/categories/${categoryId}`, {
      method: "DELETE",
    });

    router.push("/admin/categories");
  };

  return (
    <div style={{ padding: "30px" }}>
      <h1 style={{ fontSize: "28px", marginBottom: "20px" }}>
        Modifier la catégorie
      </h1>

      {error && (
        <p style={{ color: "red", marginBottom: "10px" }}>{error}</p>
      )}

      <form onSubmit={handleUpdate} style={{ marginBottom: "30px" }}>
        <label style={{ display: "block", marginBottom: "10px" }}>
          Nom de la catégorie
        </label>

        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          style={{
            padding: "10px",
            width: "300px",
            border: "1px solid #ccc",
            marginBottom: "20px",
          }}
        />

        <p style={{ color: "#666", marginBottom: "20px" }}>
          Slug actuel : <strong>{slug}</strong>
        </p>

        <button
          type="submit"
          disabled={loading}
          style={{
            padding: "10px 20px",
            background: "#0070f3",
            color: "white",
            border: "none",
            cursor: "pointer",
            marginRight: "10px",
          }}
        >
          {loading ? "Enregistrement..." : "Enregistrer"}
        </button>

        <button
          type="button"
          onClick={handleDelete}
          style={{
            padding: "10px 20px",
            background: "red",
            color: "white",
            border: "none",
            cursor: "pointer",
          }}
        >
          Supprimer
        </button>
      </form>
    </div>
  );
}
