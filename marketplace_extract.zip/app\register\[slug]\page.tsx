"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { addToCart } from "@/lib/cart";

export default function ProductPage() {
  const { slug } = useParams();
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadProduct() {
      const res = await fetch(`/api/products/${slug}`);
      const data = await res.json();
      setProduct(data);
      setLoading(false);
    }

    loadProduct();
  }, [slug]);

  if (loading) return <p>Chargement...</p>;
  if (!product) return <p>Produit introuvable.</p>;

  return (
    <div style={{ maxWidth: 1100, margin: "40px auto", padding: "20px" }}>
      <div style={{ display: "flex", gap: 40 }}>
        {/* Images */}
        <div style={{ flex: 1 }}>
          <img
            src={product.images?.[0]}
            alt={product.name}
            style={{
              width: "100%",
              borderRadius: 8,
              objectFit: "cover",
              maxHeight: 450,
            }}
          />

          {/* Miniatures */}
          <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
            {product.images?.map((img: string, i: number) => (
              <img
                key={i}
                src={img}
                style={{
                  width: 80,
                  height: 80,
                  objectFit: "cover",
                  borderRadius: 6,
                  border: "1px solid #ccc",
                }}
              />
            ))}
          </div>
        </div>

        {/* Infos produit */}
        <div style={{ flex: 1 }}>
          <h1 style={{ fontSize: 32 }}>{product.name}</h1>

          {/* Prix */}
          <div style={{ margin: "15px 0" }}>
            <span style={{ fontSize: 28, fontWeight: "bold" }}>
              {product.price} €
            </span>

            {product.originalPrice && (
              <span
                style={{
                  marginLeft: 15,
                  textDecoration: "line-through",
                  color: "gray",
                }}
              >
                {product.originalPrice} €
              </span>
            )}
          </div>

          {/* Condition */}
          <p style={{ fontSize: 14, color: "#555" }}>
            État : <strong>{product.condition}</strong>
          </p>

          {/* Stock */}
          <p style={{ fontSize: 14, color: product.stock > 0 ? "green" : "red" }}>
            {product.stock > 0
              ? `En stock (${product.stock} disponibles)`
              : "Rupture de stock"}
          </p>

          {/* Boost */}
          {product.boostLevel !== "none" && (
            <span
              style={{
                background:
                  product.boostLevel === "premium" ? "purple" : "#0070f3",
                color: "white",
                padding: "4px 10px",
                borderRadius: 4,
                fontSize: 12,
                marginTop: 10,
                display: "inline-block",
              }}
            >
              Produit mis en avant ({product.boostLevel})
            </span>
          )}

          {/* Description */}
          <p style={{ marginTop: 20, lineHeight: 1.6 }}>
            {product.description}
          </p>

          {/* Bouton ajouter au panier */}
          <button
            onClick={() => {
              addToCart(product);
              alert("Produit ajouté au panier !");
            }}
            style={{
              marginTop: 25,
              padding: "12px 20px",
              background: "black",
              color: "white",
              border: "none",
              cursor: "pointer",
              borderRadius: 6,
              fontSize: 16,
            }}
          >
            Ajouter au panier
          </button>
        </div>
      </div>

      {/* Catégorie */}
      <div style={{ marginTop: 40 }}>
        <p style={{ fontSize: 14, color: "#777" }}>
          Catégorie : {product.category}
        </p>
      </div>
    </div>
  );
}
