import { NextResponse } from "next/server";

// Fonction Haversine pour calculer la distance en km
function getDistanceKm(lat1: number, lng1: number, lat2: number, lng2: number) {
  const R = 6371; // rayon de la Terre en km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;

  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;

  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export async function GET(req: Request) {
  await connectDB();

  const { searchParams } = new URL(req.url);

  const lat = parseFloat(searchParams.get("lat") || "0");
  const lng = parseFloat(searchParams.get("lng") || "0");
  const radius = parseFloat(searchParams.get("radius") || "30"); // rayon par défaut

  if (!lat || !lng) {
    return NextResponse.json(
      { error: "Coordonnées manquantes" },
      { status: 400 }
    );
  }

  // Récupérer tous les produits actifs
  const products = await Product.find({ status: "active" }).lean();

  const results: any[] = [];

  for (const product of products) {
    const vendor = await User.findById(product.vendorId).lean();
    if (!vendor || !vendor.lat || !vendor.lng) continue;

    const distance = getDistanceKm(lat, lng, vendor.lat, vendor.lng);

    // Vérifier les deux conditions :
    // 1) distance <= radius (acheteur)
    // 2) distance <= deliveryRadiusKm (vendeur)
    if (distance <= radius && distance <= (vendor.deliveryRadiusKm || 20)) {
      results.push({
        ...product,
        distance: Math.round(distance),
      });
    }
  }

  // Trier par boost puis par distance
  results.sort((a, b) => {
    const boostOrder = { premium: 2, standard: 1, none: 0 };
    const diff = boostOrder[b.boostLevel] - boostOrder[a.boostLevel];
    if (diff !== 0) return diff;
    return a.distance - b.distance;
  });

  return NextResponse.json(results);
}
