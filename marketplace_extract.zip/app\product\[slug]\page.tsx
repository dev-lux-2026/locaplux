import Link from "next/link";
import AddToCartButton from "./AddToCartButton";

export default async function ProductPage({ params }: any) {
  const { slug } = params;

  // Charger le produit via l’API
  const product = await fetch(
    `http://localhost:3000/api/products/by-slug/${slug}`,
    { cache: "no-store" }
  ).then((r) => r.json());

  if (!product || product.error) {
    return (
      <div style={{ padding: "30px" }}>
        <h1>Produit introuvable</h1>
      </div>
    );
  }

  // Charger le vendeur
  const vendor = await fetch(
    `http://localhost:3000/api/vendors/${product.vendorId}`,
    { cache: "no-store" }
  ).then((r) => r.json());

  // Charger les produits similaires
  const similar = await fetch(
    `http://localhost:3000/api/categories/${product.categoryId}/products`,
    { cache: "no-store" }
  ).then((r) => r.json());

  const similarFiltered = similar.filter((p: any) => p._id !== product._id);

  return (
    <div style={{ padding: "30px", maxWidth: "900px", margin: "0 auto" }}>
      {/* TITRE + BOOST */}
      <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
        <h1 style={{ fontSize: "28px", margin: 0 }}>{product.name}</h1>

        {product.boostLevel !== "none" && (
          <span
            style={{
              background:
                product.boostLevel === "premium" ? "purple" : "#0070f3",
              color: "white",
              padding: "6px 10px",
              borderRadius: "6px",
              fontWeight: "bold",
              fontSize: "12px",
            }}
          >
            BOOST
          </span>
        )}
      </div>

      {/* IMAGE PRINCIPALE */}
      <img
        src={product.images?.[0]}
        alt={product.name}
        style={{
          width: "100%",
          maxWidth: "500px",
          height: "auto",
          borderRadius: "8px",
          marginTop: "20px",
        }}
      />

      {/* PRIX */}
      <div style={{ marginTop: "20px", display: "flex", gap: "15px" }}>
        <h2 style={{ fontSize: "24px", margin: 0 }}>{product.price} €</h2>

        {product.originalPrice && (
          <p
            style={{
              textDecoration: "line-through",
              color: "#888",
              fontSize: "16px",
              margin: 0,
            }}
          >
            {product.originalPrice} €
          </p>
        )}
      </div>

      {/* CATÉGORIE */}
      <p style={{ marginTop: "5px", color: "#555" }}>
        Catégorie :{" "}
        <Link
          href={`/categories/${product.categorySlug}`}
          style={{ color: "#0070f3", textDecoration: "underline" }}
        >
          {product.categorySlug}
        </Link>
      </p>

      {/* DESCRIPTION */}
      <p style={{ marginTop: "20px", lineHeight: 1.6 }}>
        {product.description}
      </p>

      {/* BOUTON PANIER */}
      <AddToCartButton product={product} />

      {/* VENDEUR */}
      <div
        style={{
          marginTop: "30px",
          padding: "15px",
          border: "1px solid #ddd",
          borderRadius: "8px",
        }}
      >
        <Link
          href={`/vendor/${vendor._id}`}
          style={{ textDecoration: "none", color: "inherit" }}
        >
          <h3 style={{ marginTop: 0 }}>Vendu par :</h3>

          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <img
              src={vendor.avatar || "/default-avatar.png"}
              alt={vendor.name}
              style={{
                width: 50,
                height: 50,
                borderRadius: "50%",
                objectFit: "cover",
              }}
            />

            <div>
              <p
                style={{
                  fontSize: "18px",
                  fontWeight: "bold",
                  margin: 0,
                }}
              >
                {vendor.name}

                {vendor.isPro && (
                  <span
                    style={{
                      background: "gold",
                      color: "black",
                      padding: "4px 8px",
                      borderRadius: "4px",
                      marginLeft: "10px",
                      fontWeight: "bold",
                      fontSize: "12px",
                    }}
                  >
                    PRO
                  </span>
                )}
              </p>

              {vendor.deliveryRadius && (
                <p style={{ margin: 0, color: "#555", fontSize: "14px" }}>
                  Livraison possible dans un rayon de {vendor.deliveryRadius} km
                </p>
              )}
            </div>
          </div>
        </Link>
      </div>

      {/* PRODUITS SIMILAIRES */}
      {similarFiltered.length > 0 && (
        <div style={{ marginTop: "40px" }}>
          <h3>Produits similaires</h3>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
              gap: "20px",
              marginTop: "20px",
            }}
          >
            {similarFiltered.map((p: any) => (
              <Link
                key={p._id}
                href={`/product/${p.slug}`}
                style={{
                  border: "1px solid #ddd",
                  padding: "10px",
                  borderRadius: "8px",
                  textDecoration: "none",
                  color: "black",
                }}
              >
                <img
                  src={p.images?.[0]}
                  alt={p.name}
                  style={{
                    width: "100%",
                    height: "150px",
                    objectFit: "cover",
                    borderRadius: "6px",
                  }}
                />
                <h4 style={{ marginTop: "10px" }}>{p.name}</h4>
                <p style={{ fontWeight: "bold" }}>{p.price} €</p>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
