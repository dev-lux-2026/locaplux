import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import slugify from "slugify";

export async function GET() {
  await connectDB();
  const products = await Product.find().sort({ createdAt: -1 });
  return NextResponse.json(products);
}

export async function POST(req: Request) {
  try {
    await connectDB();

    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });

    if (!token || token.role !== "vendor") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { name, price, stock, categoryId, condition, images, originalPrice } = body;

    if (!name || !price || !categoryId) {
      return NextResponse.json(
        { error: "Champs obligatoires manquants" },
        { status: 400 }
      );
    }

    const category = await Category.findById(categoryId);
    if (!category) {
      return NextResponse.json(
        { error: "Catégorie introuvable" },
        { status: 404 }
      );
    }

    const slug = slugify(name, { lower: true });

    const exists = await Product.findOne({ slug });
    if (exists) {
      return NextResponse.json(
        { error: "Un produit avec ce nom existe déjà" },
        { status: 400 }
      );
    }

    const product = await Product.create({
      name,
      price,
      originalPrice: originalPrice || null,
      stock: stock || 0,
      images: images || [],
      vendorId: token.id,
      categoryId,
      category: category.name,
      categorySlug: category.slug,
      condition: condition || "fin-de-serie",
      slug,
    });

    return NextResponse.json(product, { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { error: "Erreur lors de la création du produit" },
      { status: 500 }
    );
  }
}
