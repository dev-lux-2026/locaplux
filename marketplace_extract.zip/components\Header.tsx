import Link from "next/link";

export default function Header() {
  return (
    <header
      style={{
        padding: "15px 20px",
        borderBottom: "1px solid #ddd",
        display: "flex",
        gap: "20px",
        alignItems: "center",
      }}
    >
      <Link href="/" style={{ fontWeight: "bold", fontSize: "20px" }}>
        Marketplace
      </Link>

      <nav style={{ display: "flex", gap: "15px" }}>
        <Link href="/category/vetements">Vêtements</Link>
        <Link href="/category/chaussures">Chaussures</Link>
        <Link href="/category/electronique">Électronique</Link>
      </nav>
    </header>
  );
}
