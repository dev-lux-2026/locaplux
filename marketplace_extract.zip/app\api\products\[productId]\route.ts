import { NextResponse } from "next/server";
import mongoose from "mongoose";
import { getToken } from "next-auth/jwt";
import slugify from "slugify";

export async function GET(
  req: Request,
  { params }: { params: { productId: string } }
) {
  await connectDB();

  if (!mongoose.Types.ObjectId.isValid(params.productId)) {
    return NextResponse.json({ error: "ID invalide" }, { status: 400 });
  }

  const product = await Product.findById(params.productId);

  if (!product) {
    return NextResponse.json({ error: "Produit introuvable" }, { status: 404 });
  }

  return NextResponse.json(product);
}

export async function PUT(
  req: Request,
  { params }: { params: { productId: string } }
) {
  try {
    await connectDB();

    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });

    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const product = await Product.findById(params.productId);

    if (!product) {
      return NextResponse.json({ error: "Produit introuvable" }, { status: 404 });
    }

    // Vérification vendeur/admin
    if (token.role !== "admin" && token.id !== product.vendorId.toString()) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();

    // --- Champs classiques ---
    if (body.name) {
      product.name = body.name;
      product.slug = slugify(body.name, { lower: true });
    }

    if (body.price !== undefined) product.price = body.price;
    if (body.originalPrice !== undefined) product.originalPrice = body.originalPrice;
    if (body.stock !== undefined) product.stock = body.stock;
    if (body.images !== undefined) product.images = body.images;
    if (body.condition !== undefined) product.condition = body.condition;
    if (body.status !== undefined) product.status = body.status;

    // --- Catégorie ---
    if (body.categoryId) {
      const category = await Category.findById(body.categoryId);
      if (!category) {
        return NextResponse.json(
          { error: "Catégorie introuvable" },
          { status: 404 }
        );
      }
      product.categoryId = category._id;
      product.category = category.name;
      product.categorySlug = category.slug;
    }

    // --- BOOST ---
    if (body.boostLevel) {
      product.boostLevel = body.boostLevel;

      if (body.boostLevel === "none") {
        product.boostExpiresAt = null;
      } else {
        // Durée du boost : 30 jours
        const expires = new Date();
        expires.setDate(expires.getDate() + 30);
        product.boostExpiresAt = expires;
      }
    }

    await product.save();

    return NextResponse.json(product);
  } catch (error) {
    return NextResponse.json(
      { error: "Erreur lors de la mise à jour" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: { productId: string } }
) {
  try {
    await connectDB();

    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });

    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const product = await Product.findById(params.productId);

    if (!product) {
      return NextResponse.json({ error: "Produit introuvable" }, { status: 404 });
    }

    if (token.role !== "admin" && token.id !== product.vendorId.toString()) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    await Product.findByIdAndDelete(params.productId);

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { error: "Erreur lors de la suppression" },
      { status: 500 }
    );
  }
}
