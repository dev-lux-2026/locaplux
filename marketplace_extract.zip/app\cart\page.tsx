"use client";

import { useEffect, useState } from "react";
import { getCart, removeFromCart, updateQuantity } from "@/lib/cart";
import { useRouter } from "next/navigation";

export default function CartPage() {
  const [cart, setCart] = useState<any[]>([]);
  const router = useRouter();

  useEffect(() => {
    setCart(getCart());
  }, []);

  const total = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  function changeQty(id: string, qty: number) {
    updateQuantity(id, qty);
    setCart(getCart());
  }

  function remove(id: string) {
    removeFromCart(id);
    setCart(getCart());
  }

  return (
    <div style={{ padding: "30px", maxWidth: "900px", margin: "0 auto" }}>
      <h1>Votre panier</h1>

      {cart.length === 0 && <p>Votre panier est vide.</p>}

      {cart.map((item) => (
        <div
          key={item._id}
          style={{
            display: "flex",
            gap: "20px",
            borderBottom: "1px solid #ddd",
            paddingBottom: "20px",
            marginBottom: "20px",
          }}
        >
          <img
            src={item.images?.[0]}
            alt={item.name}
            style={{
              width: "120px",
              height: "120px",
              objectFit: "cover",
              borderRadius: "6px",
            }}
          />

          <div style={{ flex: 1 }}>
            <h3>{item.name}</h3>
            <p>{item.price} €</p>

            <div style={{ display: "flex", gap: "10px", marginTop: "10px" }}>
              <input
                type="number"
                min="1"
                value={item.quantity}
                onChange={(e) =>
                  changeQty(item._id, parseInt(e.target.value))
                }
                style={{ width: "60px", padding: "5px" }}
              />

              <button
                onClick={() => remove(item._id)}
                style={{
                  background: "red",
                  color: "white",
                  border: "none",
                  padding: "8px 12px",
                  borderRadius: "6px",
                  cursor: "pointer",
                }}
              >
                Supprimer
              </button>
            </div>
          </div>
        </div>
      ))}

      {cart.length > 0 && (
        <div style={{ marginTop: "30px" }}>
          <h2>Total : {total} €</h2>

          <button
            onClick={() => router.push("/checkout")}
            style={{
              padding: "15px 25px",
              background: "black",
              color: "white",
              border: "none",
              borderRadius: "6px",
              cursor: "pointer",
              marginTop: "20px",
            }}
          >
            Passer au paiement
          </button>
        </div>
      )}
    </div>
  );
}
