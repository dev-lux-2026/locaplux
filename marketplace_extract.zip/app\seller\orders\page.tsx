"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function SellerOrdersPage() {
  const { data: session, status } = useSession();
  const router = useRouter();

  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // 🔐 Protection : uniquement pour les vendeurs
  useEffect(() => {
    if (status === "loading") return;

    if (!session || session.user.role !== "vendor") {
      router.push("/login");
      return;
    }

    async function loadOrders() {
      const res = await fetch("/api/seller/orders");
      const data = await res.json();

      if (data.orders) {
        setOrders(data.orders);
      }

      setLoading(false);
    }

    loadOrders();
  }, [session, status, router]);

  if (loading) {
    return (
      <div style={{ padding: "30px", textAlign: "center" }}>
        Chargement des commandes...
      </div>
    );
  }

  return (
    <div style={{ padding: "30px", maxWidth: "900px", margin: "0 auto" }}>
      <h1>Commandes reçues</h1>

      {orders.length === 0 && (
        <p style={{ marginTop: "20px" }}>
          Vous n’avez encore reçu aucune commande.
        </p>
      )}

      <div style={{ marginTop: "30px", display: "flex", flexDirection: "column", gap: "20px" }}>
        {orders.map((order) => {
          const totalItems = order.items.reduce(
            (sum: number, item: any) => sum + item.quantity,
            0
          );

          return (
            <div
              key={order._id}
              style={{
                border: "1px solid #ddd",
                padding: "20px",
                borderRadius: "8px",
                cursor: "pointer",
              }}
              onClick={() => router.push(`/seller/orders/${order._id}`)}
            >
              <h3 style={{ margin: 0 }}>Commande #{order._id}</h3>

              <p style={{ margin: "5px 0", color: "#555" }}>
                Reçue le : {new Date(order.createdAt).toLocaleString()}
              </p>

              <p style={{ margin: "5px 0" }}>
                <strong>Total :</strong> {order.total} €
              </p>

              <p style={{ margin: "5px 0" }}>
                <strong>Articles :</strong> {totalItems}
              </p>

              <span
                style={{
                  display: "inline-block",
                  marginTop: "10px",
                  padding: "5px 10px",
                  background:
                    order.status === "pending"
                      ? "#ff9800"
                      : order.status === "shipped"
                      ? "#2196f3"
                      : "#4caf50",
                  color: "white",
                  borderRadius: "6px",
                  fontSize: "13px",
                }}
              >
                {order.status.toUpperCase()}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
