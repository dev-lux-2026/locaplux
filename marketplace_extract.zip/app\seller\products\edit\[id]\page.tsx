import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export default async function EditProductPage({ params }) {
  const session = await getServerSession();
  if (!session) redirect("/login");
  if (session.user.role !== "seller") redirect("/dashboard");

  const product = await prisma.product.findUnique({
    where: { id: params.id },
  });

  if (!product) redirect("/seller/products");

  return (
    <div className="p-10 space-y-6 max-w-xl">
      <h1 className="text-2xl font-bold">Modifier : {product.name}</h1>

      <form action="/api/products/update" method="POST" className="space-y-4">
        <input type="hidden" name="id" value={product.id} />

        <input
          name="name"
          defaultValue={product.name}
          className="border p-2 w-full"
          required
        />

        <textarea
          name="description"
          defaultValue={product.description || ""}
          className="border p-2 w-full"
        />

        <input
          name="price"
          type="number"
          defaultValue={product.price}
          className="border p-2 w-full"
          required
        />

        <input
          name="stock"
          type="number"
          defaultValue={product.stock}
          className="border p-2 w-full"
          required
        />

        <button className="px-4 py-2 bg-green-600 text-white rounded">
          Sauvegarder
        </button>
      </form>
    </div>
  );
}
